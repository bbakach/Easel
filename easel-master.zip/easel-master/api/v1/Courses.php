<?php // Courses.php

require_once("Database.php");
require_once("Status.php");

class Courses {

/********************************************************************************************
* handler
********************************************************************************************/

public static function handler($args) {

  $output = "";

  switch($_SERVER['REQUEST_METHOD']) {

    case 'DELETE':
      break;

    case 'GET':

      // courses
      if(count($args) == 0) {
        $output = $GLOBALS["db"]->selectCourses();
      }
      
      // courses/courseId
      else if(count($args) == 1) {
        $output = $GLOBALS["db"]->selectCourse($args[0]);
      }
      
      // courses/courseId/assignmentitems
      else if(count($args) == 2 && $args[1] == "assignmentitems") {
        $output = $GLOBALS["db"]->selectCourseAssignmentItems($args[0]);
      }

      // courses/courseId/modules
      else if(count($args) == 2 && $args[1] == "modules") {
        $output = $GLOBALS["db"]->selectModules($args[0]);
      }

      // courses/courseId/modules/durations
      else if(count($args) == 3 && $args[1] == "modules" && $args[2] == "durations") {
        $output = $GLOBALS["db"]->selectCourseModuleDurationTotal($args[0]);
      }

      // courses/courseId/modules/moduleId
      else if(count($args) == 3 && $args[1] == "modules") {
        $output = $GLOBALS["db"]->selectModule($args[2]);
      }

      // courses/courseId/modules/moduleId/items
      else if(count($args) == 4 && $args[3] == "items") {
        $output = $GLOBALS["db"]->selectItems($args[2]);
      }

      // courses/courseId/modules/moduleId/items/itemId
      else if(count($args) == 5 && $args[3] == "items") {
        $output = $GLOBALS["db"]->selectItem($args[4]);
      }

      else {
        $output = $args;
      }
      break;

    case 'POST':
      break;

    case 'PUT':
      // courses/courseId/duration
      if(count($args) == 2 && $args[1] == "duration") {
        $output = array();
        $courseId = $args[0];
        $courseDuration = Request::getData();
        $GLOBALS["db"]->updateCourseDuration($courseId, $courseDuration);
        $courseModuleDurationTotal = intval($GLOBALS["db"]->selectCourseModuleDurationTotal($courseId));
        $courseReservoir = $courseDuration - $courseModuleDurationTotal;
        $GLOBALS["db"]->updateCourseReservoir($courseId, $courseReservoir);
        $output["courseReservoir"] = $courseReservoir;
      }

      // courses/courseId/durations
      else if(count($args) == 2 && $args[1] == "durations") {
        $output = array();
        $courseId = $args[0];
        $courseDuration = $GLOBALS["db"]->selectCourseDuration($courseId);
        $courseItemCount = $GLOBALS["db"]->selectCourseItemCount($courseId);
        $courseItemDuration = (int) ($courseDuration / $courseItemCount);
        $GLOBALS["db"]->updateCourseItemDurations($courseId, $courseItemDuration);
        $output["courseItemDuration"] = $courseItemDuration;
        $modules = $GLOBALS["db"]->selectModules($courseId);
        $ms = array();
        foreach($modules as $module) {
          $moduleId = $module["moduleId"];
          $moduleDuration = $GLOBALS["db"]->selectModuleItemDurationTotal($moduleId);
          $GLOBALS["db"]->updateModuleDuration($moduleId, $moduleDuration);
          $m = array();
          $m["moduleId"] = $moduleId;
          $m["moduleDuration"] = $moduleDuration;
          array_push($ms, $m);
        }
        $GLOBALS["db"]->updateCourseModuleReservoirs($courseId, 0);
        $output["modules"] = $ms;
        $courseModuleDurationTotal = intval($GLOBALS["db"]->selectCourseModuleDurationTotal($courseId));
        $courseReservoir = $courseDuration - $courseModuleDurationTotal;
        $GLOBALS["db"]->updateCourseReservoir($courseId, $courseReservoir);
        $output["courseReservoir"] = $courseReservoir;
      }

      else {
        $output = $args;
      }
      break;

    default:
      http_response_code(Status::INTERNAL_SERVER_ERROR);
      break;
  }

  return json_encode($output, JSON_PRETTY_PRINT);
}

}
?>