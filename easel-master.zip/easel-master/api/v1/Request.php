<?php //Request.php

require_once 'Status.php';

class Request {

  /**
   * This method ...
   */
  public static function getContains($default) {
    if(isset($_GET["cn"])) {return $_GET["cn"];}
    else if(isset($_GET["contains"])) {return $_GET["contains"];}
    else {return $default;}
  }

  /**
   * This method ...
   */
  public static function getCookies() {
    return $_COOKIE;
  }

  /**
   * This method ...
   */
  public static function getDebug() {
    if(isset($_GET["d"])) {$v = $_GET["d"];}
    else if(isset($_GET["debug"])) {$v = $_GET["debug"];}
    else {return false;}
    if(is_numeric($v) && $v==0) {return false;} 
    else if(is_string($v) && $v=='false') {return false;}
    else {return true;}
  }

  /**
   * This method ...
   */
  public static function getEndsWith($default) {
    if(isset($_GET["ew"])) {return $_GET["ew"];}
    else if(isset($_GET["endsWith"])) {return $_GET["endsWith"];}
    else {return $default;}
  }

  /**
   * This method ...
   */
  public static function getEquals($default) {
    if(isset($_GET["eq"])) {return $_GET["eq"];}
    else if(isset($_GET["equals"])) {return $_GET["equals"];}
    else {return $default;}
  }

  /**
   * This method ...
   */
  public static function getLimit($default) {
    if(isset($_GET["lm"])) {return $_GET["lm"];}
    else if(isset($_GET["limit"])) {return $_GET["limit"];}
    else {return $default;}
  }

  /**
   * This method ...
   */
  public static function getMineOnly($default) {
    if(isset($_GET["mo"])) {$v = $_GET["mo"];}
    else if(isset($_GET["mineOnly"])) {$v = $_GET["mineOnly"];}
    else {return $default;}
    if(is_numeric($v) && $v==0) {return false;} 
    else if(is_string($v) && $v=='false') {return false;}
    else if(is_numeric($v) && $v==1) {return true;}
    else if(is_string($v) && $v=='true') {return true;}
    else {throw new SurveyEx('Unsupported URL Parameter: mo='.$v, Status::BAD_REQUEST);}
  }

  /**
   * This method ...
   */
  public static function getOrderBy($default) {
    if(isset($_GET["ob"])) {return $_GET["ob"];}
    else if(isset($_GET["orderBy"])) {return $_GET["orderBy"];}
    else {return $default;}
  }

  /**
   * This method ...
   */
  public static function getData() {
    return json_decode(file_get_contents('php://input'), true);
  }

  /**
   * This method ...
   */
  public static function getMethod() {
    return $_SERVER['REQUEST_METHOD'];
  }

  /**
   * This method ...
   */
  public static function getPassword() {
    if(isset($_SERVER['PHP_AUTH_PW'])) {return $_SERVER['PHP_AUTH_PW'];}
    else return '';
  }

  /**
   * This method ...
   */
  public static function getResource() {
    $url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    $urlArray = parse_url($url);
    $path = $urlArray['path'];
    $pathArray = explode('/',$path);
    return $pathArray[count($pathArray)-1];
  }

  /**
   * This method ...
   */
  public static function getUsername() {
    if(isset($_SERVER['PHP_AUTH_USER'])) {return $_SERVER['PHP_AUTH_USER'];}
    else return '';
  }

  /**
   * This method ...
   */
  public static function getResponseContent($default) {
    if(isset($_GET["rc"])) {return $_GET["rc"];}
    else if(isset($_GET["responseContent"])) {return $_GET["responseContent"];}
    else {return $default;}
  }

  /**
   * This method ...
   */
  public static function getStartsWith($default) {
    if(isset($_GET["sw"])) {return $_GET["sw"];}
    else if(isset($_GET["startsWith"])) {return $_GET["startsWith"];}
    else {return $default;}
  }

  /**
   * This method ...
   */
  public static function getSurveyId() {
    if(isset($_GET["sId"])) {return $_GET["sId"];}
    else if(isset($_GET["surveyId"])) {return $_GET["surveyId"];}
    throw new SurveyEx('No Survey Id', Status::NOT_FOUND);
  }

  /**
   * This method ...
   */
  public static function getValidateOnly($default) {
    if(isset($_GET["vo"])) {$v = $_GET["vo"];}
    else if(isset($_GET["validateOnly"])) {$v = $_GET["validateOnly"];}
    else {return $default;}
    if(is_numeric($v) && $v==0) {return false;} 
    else if(is_string($v) && $v=='false') {return false;}
    else if(is_numeric($v) && $v==1) {return true;}
    else if(is_string($v) && $v=='true') {return true;}
    else {throw new SurveyEx('Unsupported URL Parameter: vo='.$v, Status::BAD_REQUEST);}
  }

}

?>