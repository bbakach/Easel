<?php // Canvas.php

require_once("Config.php");
require_once("Peer.php");
require_once("Request.php");
require_once("Status.php");

class Canvas extends Peer {

/********************************************************************************************
* handler
********************************************************************************************/

public static function handler($args) {

  switch($_SERVER['REQUEST_METHOD']) {

    case 'DELETE':
      if(count($args) == 3 && $args[0] == "courses" && $args[2] == "assignments") {
        $data = Request::getData();
        $canvas = new Canvas();
        $overrides = array();
 
        for($i = 0; $i < count($data["assignmentId"]); ++$i) {

          $override = $canvas->deleteAssignmentOverride(
            $args[1], 
            $data["assignmentId"][$i], 
            $data["overrideId"][$i]
          );

          array_push($overrides, json_decode($override, true));
        }

        return json_encode($overrides, JSON_PRETTY_PRINT);
      }

      else {
        $output = $args;
      }
      break;

    case 'GET':
      if(count($args) == 1 && $args[0] == "test") {
        $canvas = new Canvas();
        return $canvas->test();
      }

      else if(count($args) == 1 && $args[0] == "courses") {
        $canvas = new Canvas();
        return $canvas->courses();
      }

      else if(count($args) == 2 && $args[0] == "courses") {
        $canvas = new Canvas();
        return $canvas->courses($args[1]);
      }

      else if(count($args) == 1 && $args[0] == "users") {
        $canvas = new Canvas();
        return $canvas->users();
      }

      else if(count($args) == 2 && $args[0] == "users") {
        $canvas = new Canvas();
        return $canvas->users($args[1]);
      }

      else if(count($args) == 3 && $args[0] == "users" && $args[2] == "courses") {
        $canvas = new Canvas();
        return $canvas->userCourses($args[1]);
      }

      else if(count($args) == 5 && $args[0] == "courses" && $args[2] == "students" && $args[4] == "submissions") {
        $canvas = new Canvas();
        return $canvas->getUserSubmissions($args[1], $args[3]);
      }

      else if(count($args) == 5 && $args[0] == "users" && $args[2] == "courses" && $args[4] == "assignments") {
        $canvas = new Canvas();
        return $canvas->getUserAssignmentsAndOverrides($args[1], $args[3]);
      }

      else {
        $output = $args;
      }
      break;

    case 'POST':
      if(count($args) == 3 && $args[0] == "courses" && $args[2] == "assignments") {
        $data = Request::getData();
        $canvas = new Canvas();
        $overrides = array();
        for($i = 0; $i < count($data["assignmentId"]); ++$i) {

          if($data["overrideId"][$i]) {
            $canvas->deleteAssignmentOverride(
              $args[1], 
              $data["assignmentId"][$i], 
              $data["overrideId"][$i]
            );
          }

          $override = $canvas->createAssignmentOverride(
            $args[1], 
            $data["assignmentId"][$i], 
            $data["userId"], 
            $data["userName"], 
            $data["dueDate"][$i]
          );
          array_push($overrides, json_decode($override, true));
        }
        return json_encode($overrides, JSON_PRETTY_PRINT);
      }

      else if(count($args) == 4 && $args[0] == "courses" && $args[2] == "assignments") {
        $data = Request::getData();
        $canvas = new Canvas();
        return $canvas->createAssignmentOverride($args[1], $args[3], $data["userId"], $data["userName"], $data["dueDate"]);
      }

      else {
        $output = $args;
      }
      break;

    default:
      http_response_code(Status::INTERNAL_SERVER_ERROR);
      return "Happy";
  }
}

/********************************************************************************************
 construct
********************************************************************************************/

public function __construct(){
  parent::__construct();
}

/********************************************************************************************
 destruct
********************************************************************************************/

public function __destruct() {
  parent::__destruct();
}

/********************************************************************************************
 getAccounts
********************************************************************************************/

public function getAccounts(){
  $data = array();
  $account = json_decode($this->getAccount(Config::CANVAS_ACCOUNT_ID), true);
  array_push($data, $account);
  $this->getAllSubAccounts($account["id"], $data);
  return json_encode($data, JSON_PRETTY_PRINT);
}

/********************************************************************************************
 getAccount
********************************************************************************************/

public function getAccount($accountId){
  $json = "";
  $this->get("/api/v1/accounts/{$accountId}");
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 getAllSubAccounts
********************************************************************************************/

public function getAllSubAccounts($accountId, &$data){
  $subAccounts = json_decode($this->getSubAccounts($accountId), true);
  if(count($subAccounts) > 0) {
    $data = array_merge($data, $subAccounts);
    foreach ($subAccounts as $subAccount) {
      $this->getAllSubAccounts($subAccount["id"], $data);
    }
  }
}

/********************************************************************************************
 getSubAccounts
********************************************************************************************/

public function getSubAccounts($accountId){
  $json = "";
  $this->get("/api/v1/accounts/{$accountId}/sub_accounts");
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 courses
********************************************************************************************/

public function courses($courseId=-1){
  $json = "";
  if($courseId == -1) {
    $this->get("/api/v1/courses?per_page=1000");
  } else {
    $this->get("/api/v1/courses/{$courseId}");
  }
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 modules
********************************************************************************************/

public function modules($courseId, $moduleId=-1){
  $json = "";
  if($moduleId == -1) {
    $this->get("/api/v1/courses/{$courseId}/modules?per_page=1000");
  } else {
    $this->get("/api/v1/courses/{$courseId}/modules/{$moduleId}");
  }
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 items
********************************************************************************************/

public function items($courseId, $moduleId, $itemId=-1){
  $json = "";
  if($itemId == -1) {
    $this->get("/api/v1/courses/{$courseId}/modules/{$moduleId}/items?per_page=1000");
  } else {
    $this->get("/api/v1/courses/{$courseId}/modules/{$moduleId}/items/{$itemId}");
  }
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 getQuizItemAssignmentId
********************************************************************************************/

public function getQuizItemAssignmentId($courseId, $contentId){
  $assignmentId = null;
  $this->get("/api/v1/courses/{$courseId}/quizzes/{$contentId}");
  if(!$this->err) {
    $json = $this->response;
    $a = json_decode($json, true);
    $assignmentId = $a["assignment_id"];
  }
  return $assignmentId;
}

/********************************************************************************************
 getDiscussionItemAssignmentId
********************************************************************************************/

public function getDiscussionItemAssignmentId($courseId, $contentId){
  $assignmentId = null;
  $this->get("/api/v1/courses/{$courseId}/discussion_topics/{$contentId}");
  if(!$this->err) {
    $json = $this->response;
    $a = json_decode($json, true);
    $assignmentId = $a["assignment_id"];
  }
  return $assignmentId;
}

/********************************************************************************************
 users
********************************************************************************************/

public function users($userId=-1) {
  $json = "";  
  if($userId == -1) {
    $this->get("/api/v1/accounts/".Config::CANVAS_ACCOUNT_ID."/users?per_page=1000");
  } else {
    $this->get("/api/v1/accounts/".Config::CANVAS_ACCOUNT_ID."/users?search_term={$userId}");
  }
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 userCourses
********************************************************************************************/

public function userCourses($userId) {
  $json = "";  
  $this->get("/api/v1/users/{$userId}/courses?per_page=1000");
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 createAssignmentOverride
********************************************************************************************/

public function createAssignmentOverride($courseId, $assignmentId, $userId, $userName, $dueDate){
  $json = ''; 

  $data = ""
    ."--MMM\r\nContent-Disposition: form-data; name=\"assignment_override[student_ids][]\"\r\n\r\n".$userId."\r\n"
    ."--MMM\r\nContent-Disposition: form-data; name=\"assignment_override[title]\"\r\n\r\n".$userName."\r\n"
    ."--MMM\r\nContent-Disposition: form-data; name=\"assignment_override[due_at]\"\r\n\r\n".$dueDate."\r\n"
    ."--MMM--";
  
  $this->post("/api/v1/courses/{$courseId}/assignments/{$assignmentId}/overrides", $data);
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 deleteAssignmentOverride
********************************************************************************************/

public function deleteAssignmentOverride($courseId, $assignmentId, $overrideId){
  $json = ''; 
  $this->delete("/api/v1/courses/{$courseId}/assignments/{$assignmentId}/overrides/{$overrideId}");
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 getUserSubmissions
********************************************************************************************/

public function getUserSubmissions($courseId, $userId){
  $json = ''; 

  $data = ""
    ."--MMM\r\nContent-Disposition: form-data; name=\"student_ids[]\"\r\n\r\n".$userId."\r\n"
    ."--MMM--";
  
  $this->getWithParms("/api/v1/courses/{$courseId}/students/submissions", $data);
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 getUserAssignmentsAndOverrides
********************************************************************************************/

public function getUserAssignmentsAndOverrides($userId, $courseId){
  $json = ''; 

  $data = ""
    ."--MMM\r\nContent-Disposition: form-data; name=\"include[]\"\r\n\r\nall_dates\r\n"
    ."--MMM--";
  
  $this->getWithParms("/api/v1/users/{$userId}/courses/{$courseId}/assignments", $data);
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

/********************************************************************************************
 test
********************************************************************************************/

public function test(){
  $json = ''; 

  $data = ""
    ."--MMM\r\nContent-Disposition: form-data; name=\"include[]\"\r\n\r\noverrides\r\n"
    ."--MMM--";
  
  $this->getWithParms("/api/v1/courses/20/assignments", $data);
  if($this->err) {
    http_response_code(Status::NOT_FOUND);
    $json = $this->err;
  } else {
    $json = $this->response;
  }
  return $json;
}

}
?>
