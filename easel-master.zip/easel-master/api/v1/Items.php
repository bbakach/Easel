<?php // Items.php

require_once("Database.php");
require_once("Status.php");

class Items {

/********************************************************************************************
* handler
********************************************************************************************/

public static function handler($args) {

  $output = "";

  switch($_SERVER['REQUEST_METHOD']) {

    case 'DELETE':
      break;

    case 'GET':
      break;

    case 'POST':
      break;

    case 'PUT':
      // items/itemId/duration
      if(count($args) == 2 && $args[1] == "duration") {
        $output = array();
        $itemId = $args[0];
        $itemDuration = Request::getData();
        $GLOBALS["db"]->updateItemDuration($itemId, $itemDuration);
        $moduleId = $GLOBALS["db"]->getModuleIdForItemId($itemId);
        $moduleDuration = $GLOBALS["db"]->selectModuleDuration($moduleId);
        $moduleItemDurationTotal = intval($GLOBALS["db"]->selectModuleItemDurationTotal($moduleId));
        $moduleReservoir = $moduleDuration - $moduleItemDurationTotal;
        $GLOBALS["db"]->updateModuleReservoir($moduleId, $moduleReservoir);
        $output["moduleReservoir"] = $moduleReservoir;
      }

      else {
        $output = $args;
      }
      break;

    default:
      http_response_code(Status::INTERNAL_SERVER_ERROR);
      break;
  }

  return json_encode($output, JSON_PRETTY_PRINT);
}

}
?>