<?php

function toSTime($i) {
  $sign = "";
  $m = 0;
  $h = 0;

  if($i < 0) {$sign = "-";}

  $i = abs($i);

  if($i >= 60) {
    $m = $i % 60; 
    $h = ($i - $m) / 60;
  } else {
    $m = $i; 
  }
  return $sign.$h.":".sprintf("%02d", $m);
}

function toITime($s) {
  $hm = explode(":", $s);
  $h = $hm[0] * 60;
  $m = $hm[1] * 1;
  return $h + $m;
}


echo toSTime(5);
echo "<br />";
echo toSTime(55);
echo "<br />";
echo toSTime(60);
echo "<br />";
echo toSTime(200);
echo "<br />";
echo toSTime(4500);
echo "<br />";
echo toSTime(-5);
echo "<br />";
echo toSTime(-55);
echo "<br />";
echo toSTime(-60);
echo "<br />";
echo toSTime(-200);
echo "<br />";
echo toSTime(-4500);
echo "<br />";
echo "<br />";
echo toITime("0:05");
echo "<br />";
echo toITime("0:55");
echo "<br />";
echo toITime("1:00");
echo "<br />";
echo toITime("3:20");
echo "<br />";
echo toITime("75:00");
echo "<br />";
echo toITime("-0:05");
echo "<br />";
echo toITime("-0:55");
echo "<br />";
echo toITime("-1:00");
echo "<br />";
echo toITime("-3:20");
echo "<br />";
echo toITime("-75:00");
echo "<br />";

?>