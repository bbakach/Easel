<?php // Database.php

require_once("Status.php");
  
class Database extends mysqli {

/********************************************************************************************
* construct
********************************************************************************************/

public function __construct($dbHostname, $dbUsername, $dbPassword, $dbName) {
  $driver = new mysqli_driver();
  $driver->report_mode = MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT;
  parent::__construct($dbHostname, $dbUsername, $dbPassword, $dbName);
}

/********************************************************************************************
* authenticate
********************************************************************************************/

public function authenticate() {
  $admin = array();
  $admin["adminId"] = 0;
  $admin["loginId"] = "";
  $admin["authcode"] = 0;
  $loginId = $_SERVER['PHP_AUTH_USER'];
  $pwd = md5($_SERVER['PHP_AUTH_PW']);
  $sql = 'select adminId, password, authcode from Admins where loginId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('s', $loginId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($adminId, $password, $authcode);
  if($stmt->fetch()) {
    if(strcmp($pwd, $password) == 0) {
      $admin["adminId"] = $adminId;
      $admin["loginId"] = $loginId;
      $admin["authcode"] = $authcode;
    }
  }
  return $admin;
}

/********************************************************************************************
* selectSets
********************************************************************************************/

public function selectSets($where=null, $orderBy=null) {
  $sql = 'select setId, name, abbrev, parentId, duration, reservoir, position from Sets';
  if(isset($where)) {$sql = $sql.' '.$where;}
  if(isset($orderBy)) {$sql = $sql.' '.$orderBy;}
  else {$sql = $sql.' order by name asc';}
  $stmt = $this->prepare($sql);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($setId, $name, $abbrev, $parentId, $duration, $reservoir, $position);
  $data = array();
  while($stmt->fetch()) {
    $set = array();
    $set["setId"] = $setId;
    $set["name"] = $name;
    $set["abbrev"] = $abbrev;
    $set["parentId"] = $parentId;
    $set["duration"] = $duration;
    $set["reservoir"] = $reservoir;
    $set["position"] = $position;
    array_push($data, $set);
  }
  $stmt->close();
  return $data;
}

/********************************************************************************************
* selectSet
********************************************************************************************/

public function selectSet($setId) {
  $sql = 'select setId, name, abbrev, parentId, duration, reservoir, position from Sets where setId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $setId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($setId, $name, $abbrev, $parentId, $duration, $reservoir, $position);
  if(!$stmt->fetch()){
    throw new Exception('No set found where setId='.$setId, Status::NOT_FOUND);
  }
  $set = array();
  $set["setId"] = $setId;
  $set["name"] = $name;
  $set["abbrev"] = $abbrev;
  $set["parentId"] = $parentId;
  $set["duration"] = $duration;
  $set["reservoir"] = $reservoir;
  $set["position"] = $position;
  $stmt->close();
  return $set;  
}

/********************************************************************************************
* createSet
********************************************************************************************/

public function createSet($input) {
  $sql = 'insert into Sets (name, abbrev, duration, parentId, position) VALUES (?,?,?,?,?)';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('ssiii', $input['name'], $input['abbrev'], $input['duration'], $input['parentId'], $input['position']);
  $stmt->execute();
  $stmt->close();
  $input["setId"] = $this->insert_id;;
  return $input;
}

/********************************************************************************************
* deleteSets
********************************************************************************************/

public function deleteSets($where=null) {
  $sql = 'delete from Sets';
  if(isset($where)) {$sql = $sql.' '.$where;}
  $stmt = $this->prepare($sql);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* deleteSet
********************************************************************************************/

public function deleteSet($setId) {
  $sql = 'delete from Sets where setId=?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $setId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* selectSetCourses
********************************************************************************************/

public function selectSetCourses($setId, $orderBy=null) {
  $sql = 'select c.courseId, c.name, c.accountId, c.duration, c.updated, sc.position'
    .' from Courses as c'
    .' join SetsCourses as sc on c.courseId = sc.courseId'
    .' where sc.setId = ?';
  if(isset($orderBy)) {$sql = $sql.' '.$orderBy;}
  else {$sql = $sql.' order by sc.position asc';}
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $setId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($courseId, $name, $accountId, $duration, $updated, $position);
  $data = array();
  while($stmt->fetch()) {
    $course = array();
    $course["courseId"] = $courseId;
    $course["name"] = $name;
    $course["accountId"] = $accountId;
    $course["duration"] = $duration;
    $course["updated"] = $updated;
    $course["position"] = $position;
    array_push($data, $course);
  }
  $stmt->close();
  return $data;
}

/********************************************************************************************
* updateSetName
********************************************************************************************/

public function updateSetName($setId, $name) {

  $sql = 'update Sets set name = ? where setId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('si', $name, $setId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* updateSetDuration
********************************************************************************************/

public function updateSetDuration($setId, $duration) {

  $sql = 'update Sets set duration = ? where setId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('ii', $duration, $setId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* selectAccounts
********************************************************************************************/

public function selectAccounts($where=null, $orderBy=null) {
  $sql = 'select accountId, name, parentId, updated from Accounts';
  if(isset($where)) {$sql = $sql.' '.$where;}
  if(isset($orderBy)) {$sql = $sql.' '.$orderBy;}
  else {$sql = $sql.' order by name asc';}
  $stmt = $this->prepare($sql);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($accountId, $name, $parentId, $updated);
  $data = array();
  while($stmt->fetch()) {
    $account = array();
    $account["accountId"] = $accountId;
    $account["name"] = $name;
    $account["parentId"] = $parentId;
    $account["updated"] = $updated;
    array_push($data, $account);
  }
  $stmt->close();
  return $data;
}

/********************************************************************************************
* selectAccount
********************************************************************************************/

public function selectAccount($accountId) {
  $sql = 'select accountId, name, parentId, updated from Accounts where accountId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $accountId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($accountId, $name, $parentId, $updated);
  if(!$stmt->fetch()){
    throw new Exception('No account found where accoundId='.$accountId, Status::NOT_FOUND);
  }
  $account = array();
  $account["accountId"] = $accountId;
  $account["name"] = $name;
  $account["parentId"] = $parentId;
  $account["updated"] = $updated;
  $stmt->close();
  return $account;
}

/********************************************************************************************
* selectCourses
********************************************************************************************/

public function selectCourses($where=null, $orderBy=null) {
  $sql = 'select courseId, name, accountId, duration, reservoir, updated from Courses';
  if(isset($where)) {$sql = $sql.' '.$where;}
  if(isset($orderBy)) {$sql = $sql.' '.$orderBy;}
  else {$sql = $sql.' order by name asc';}
  $stmt = $this->prepare($sql);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($courseId, $name, $accountId, $duration, $reservoir, $updated);
  $data = array();
  while($stmt->fetch()) {
    $course = array();
    $course["courseId"] = $courseId;
    $course["name"] = $name;
    $course["accountId"] = $accountId;
    $course["duration"] = $duration;
    $course["reservoir"] = $reservoir;
    $course["updated"] = $updated;
    array_push($data, $course);
  }
  $stmt->close();
  return $data;
}

/********************************************************************************************
* selectCourse
********************************************************************************************/

public function selectCourse($courseId) {
  $sql = 'select courseId, name, accountId, duration, reservoir, updated from Courses where courseId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $courseId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($courseId, $name, $accountId, $duration, $reservoir, $updated);
  if(!$stmt->fetch()){
    throw new Exception('No course found where courseId='.$courseId, Status::NOT_FOUND);
  }
  $course = array();
  $course["courseId"] = $courseId;
  $course["name"] = $name;
  $course["accountId"] = $accountId;
  $course["duration"] = $duration;
  $course["reservoir"] = $reservoir;
  $course["updated"] = $updated;
  $stmt->close();
  return $course;
}

/********************************************************************************************
* getCourseIdForModuleId
********************************************************************************************/

public function getCourseIdForModuleId($moduleId) {
  $sql = 'select courseId from Modules where moduleId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $moduleId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($courseId);
  if(!$stmt->fetch()){
    throw new Exception('No module found where moduleId='.$moduleId, Status::NOT_FOUND);
  }
  return $courseId;
}

/********************************************************************************************
* getModuleIdForItemId
********************************************************************************************/

public function getModuleIdForItemId($itemId) {
  $sql = 'select moduleId from Items where itemId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $itemId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($moduleId);
  if(!$stmt->fetch()){
    throw new Exception('No item found where itemId='.$itemId, Status::NOT_FOUND);
  }
  return $moduleId;
}

/********************************************************************************************
* selectCourseDuration
********************************************************************************************/

public function selectCourseDuration($courseId) {
  $sql = 'select duration from Courses where courseId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $courseId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($duration);
  if(!$stmt->fetch()){
    throw new Exception('No course found where courseId='.$courseId, Status::NOT_FOUND);
  }
  return $duration;
}

/********************************************************************************************
* selectModuleDuration
********************************************************************************************/

public function selectModuleDuration($moduleId) {
  $sql = 'select duration from Modules where moduleId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $moduleId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($duration);
  if(!$stmt->fetch()){
    throw new Exception('No module found where moduleId='.$moduleId, Status::NOT_FOUND);
  }
  return $duration;
}

/********************************************************************************************
* updateCourseDuration
********************************************************************************************/

public function updateCourseDuration($courseId, $duration) {
  $sql = 'update Courses set duration = ? where courseId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('ii', $duration, $courseId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* updateCourseReservoir
********************************************************************************************/

public function updateCourseReservoir($courseId, $reservoir) {
  $sql = 'update Courses set reservoir = ? where courseId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('ii', $reservoir, $courseId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* updateCourseModuleReservoirs
********************************************************************************************/

public function updateCourseModuleReservoirs($courseId, $reservoir) {
  $sql = 'update Modules set reservoir = ? where courseId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('ii', $reservoir, $courseId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* updateModuleReservoir
********************************************************************************************/

public function updateModuleReservoir($moduleId, $reservoir) {
  $sql = 'update Modules set reservoir = ? where moduleId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('ii', $reservoir, $moduleId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* selectModules
********************************************************************************************/

public function selectModules($courseId) {
  $sql = 'select moduleId, name, position, duration, reservoir, updated from Modules where courseId = ? order by position asc';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $courseId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($moduleId, $name, $position, $duration, $reservoir, $updated);
  $data = array();
  while($stmt->fetch()) {
    $module = array();
    $module["moduleId"] = $moduleId;
    $module["name"] = $name;
    $module["courseId"] = $courseId;
    $module["position"] = $position;
    $module["duration"] = $duration;
    $module["reservoir"] = $reservoir;
    $module["updated"] = $updated;
    array_push($data, $module);
  }
  $stmt->close();
  return $data;
}

/********************************************************************************************
* selectModule
********************************************************************************************/

public function selectModule($moduleId) {
  $sql = 'select moduleId, name, courseId, position, duration, reservoir, updated from Modules where moduleId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $moduleId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($moduleId, $name, $courseId, $position, $reservoir, $duration, $updated);
  if(!$stmt->fetch()){
    throw new Exception('No module found where moduleId='.$moduleId, Status::NOT_FOUND);
  }
  $module = array();
  $module["moduleId"] = $moduleId;
  $module["name"] = $name;
  $module["courseId"] = $courseId;
  $module["position"] = $position;
  $module["duration"] = $duration;
  $module["reservoir"] = $reservoir;
  $module["updated"] = $updated;
  $stmt->close();
  return $module;
}

/********************************************************************************************
* selectCourseModuleDurationTotal
********************************************************************************************/

public function selectCourseModuleDurationTotal($courseId) {
  $sql = 'select sum(duration) as total from Modules where courseId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $courseId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($total);
  if(!$stmt->fetch()){
    throw new Exception('No module found where moduleId='.$moduleId, Status::NOT_FOUND);
  }
  return $total;
}

/********************************************************************************************
* selectModuleItemDurationTotal
********************************************************************************************/

public function selectModuleItemDurationTotal($moduleId) {
  $sql = 'select sum(duration) as total from Items where moduleId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $moduleId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($total);
  if(!$stmt->fetch()){
    throw new Exception('No module found where moduleId='.$moduleId, Status::NOT_FOUND);
  }
  return $total;
}

/********************************************************************************************
* updateModuleDuration
********************************************************************************************/

public function updateModuleDuration($moduleId, $duration) {
  $sql = 'update Modules set duration = ? where moduleId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('ii', $duration, $moduleId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* selectItems
********************************************************************************************/

public function selectItems($moduleId) {
  $sql = 'select itemId, name, contentType, assignmentId, position, duration, updated from Items where moduleId = ? order by position asc';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $moduleId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($itemId, $name, $contentType, $assignmentId, $position, $duration, $updated);
  $data = array();
  while($stmt->fetch()) {
    $item = array();
    $item["itemId"] = $itemId;
    $item["name"] = $name;
    $item["contentType"] = $contentType;
    $item["assignmentId"] = $assignmentId;
    $item["moduleId"] = $moduleId;
    $item["position"] = $position;
    $item["duration"] = $duration;
    $item["updated"] = $updated;
    array_push($data, $item);
  }
  $stmt->close();
  return $data;
}

/********************************************************************************************
* selectItem
********************************************************************************************/

public function selectItem($itemId) {
  $sql = 'select itemId, name, moduleId, position, duration, updated from Items where itemId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $itemId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($itemId, $name, $moduleId, $position, $duration, $updated);
  if(!$stmt->fetch()){
    throw new Exception('No item found where itemId='.$itemId, Status::NOT_FOUND);
  }
  $item = array();
  $item["itemId"] = $itemId;
  $item["name"] = $name;
  $item["moduleId"] = $moduleId;
  $item["position"] = $position;
  $item["duration"] = $duration;
  $item["updated"] = $updated;
  $stmt->close();
  return $item;
}

/********************************************************************************************
* selectCourseItemCount
********************************************************************************************/

public function selectCourseItemCount($courseId) {

  $sql = 'select count(*) from Items where courseId = '.$courseId;
  $this->multi_query($sql);
  if($result = $this->store_result()) {
    if($row = $result->fetch_row()) {
      return $row[0];
    }
  }

  /*
  $sql = 'select count(*) as cnt from Items where courseId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $courseId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($count);
  return $count;
  */
}

/********************************************************************************************
* updateItemDuration
********************************************************************************************/

public function updateItemDuration($itemId, $duration) {

  $sql = 'update Items set duration = ? where itemId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('ii', $duration, $itemId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* updateCourseItemDurations
********************************************************************************************/

public function updateCourseItemDurations($courseId, $duration) {

  $sql = 'update Items set duration = ? where courseId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('ii', $duration, $courseId);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* insertOrUpdateAccounts
********************************************************************************************/

public function insertOrUpdateAccounts($accounts, $updated) {
  foreach ($accounts as $account) {
    $this->insertOrUpdateAccount($account, $updated);
  }
}

/********************************************************************************************
* insertOrUpdateAccount
********************************************************************************************/

public function insertOrUpdateAccount($account, $updated) {
  $accountId = $account['id'];
  $name = $account['name'];
  $parentId = $account['parent_account_id'];
  if($account['parent_account_id'] == NULL) {$parentId=0;}
  $sql = 'insert into Accounts (accountId, name, parentId, updated)'
    .' values(?,?,?,?)'
    .' on duplicate key update name = ?, parentId = ?, updated = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('isissis', $accountId, $name, $parentId, $updated, $name, $parentId, $updated);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* deleteOldAccounts
********************************************************************************************/

public function deleteOldAccounts($updated) {
  $sql = 'delete from Accounts where updated < ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('s', $updated);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* insertOrUpdateCourses
********************************************************************************************/

public function insertOrUpdateCourses($courses, $updated) {
  foreach ($courses as $course) {
    $this->insertOrUpdateCourse($course, $updated);
  }
}

/********************************************************************************************
* insertOrUpdateCourse
********************************************************************************************/

public function insertOrUpdateCourse($course, $updated) {
  $courseId = $course['id'];
  $name = $course['name'];
  $accountId = $course['account_id'];
  $sql = 'insert into Courses (courseId, name, accountId, updated) values(?,?,?,?)'
    .' on duplicate key update name = ?, accountId = ?, updated = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('isissis', $courseId, $name, $accountId, $updated, $name, $accountId, $updated);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* deleteOldCourses
********************************************************************************************/

public function deleteOldCourses($updated) {
  $sql = 'delete from Courses where updated < ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('s', $updated);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* insertOrUpdateModules
********************************************************************************************/

public function insertOrUpdateModules($courseId, $modules, $updated) {
  foreach ($modules as $module) {
    $this->insertOrUpdateModule($courseId, $module, $updated);
  }
}

/********************************************************************************************
* insertOrUpdateModule
********************************************************************************************/

public function insertOrUpdateModule($courseId, $module, $updated) {
  $moduleId = $module['id'];
  $name = $module['name'];
  $position = $module['position'];
  $sql = ''
    .' insert into Modules (moduleId, name, courseId, position, updated) values(?,?,?,?,?)'
    .' on duplicate key update name = ?, courseId = ?, position = ?, updated = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('isiissiis', $moduleId, $name, $courseId, $position, $updated, $name, $courseId, $position, $updated);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* deleteOldModules
********************************************************************************************/

public function deleteOldModules($updated) {
  $sql = 'delete from Modules where updated < ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('s', $updated);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* insertOrUpdateItems
********************************************************************************************/

public function insertOrUpdateItems($courseId, $items, $updated) {
  foreach ($items as $item) {
    $this->insertOrUpdateItem($courseId, null, $item, $updated);
  }
}
 
/********************************************************************************************
* insertOrUpdateItem
********************************************************************************************/

public function insertOrUpdateItem($courseId, $assignmentId, $item, $updated) {
  $itemId = $item['id'];
  $name = $item['title'];
  $contentType = $item['type'];
  $moduleId = $item['module_id'];
  $position = $item['position'];
  $sql = ''
    .' insert into Items (itemId, name, contentType, assignmentId, courseId, moduleId, position, updated) values(?,?,?,?,?,?,?,?)'
    .' on duplicate key update name = ?, contentType = ?, assignmentId = ?, courseId = ?, moduleId = ?, position = ?, updated = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('issiiiisssiiiis', $itemId, $name, $contentType, $assignmentId, $courseId, 
    $moduleId, $position, $updated, $name, $contentType, $assignmentId, $courseId, $moduleId, $position, $updated);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* deleteOldItems
********************************************************************************************/

public function deleteOldItems($updated) {
  $sql = 'delete from Items where updated < ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('s', $updated);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* relateSetAndCourses
********************************************************************************************/

public function relateSetAndCourses($setId, $courseIds) {  
  $sql = 'delete from SetsCourses where setId=?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $setId);
  $stmt->execute();
  $stmt->close();

  foreach ($courseIds as $position=>$courseId) {

    $sql = 'insert into SetsCourses (setId, courseId, position) values(?,?,?)';
    $stmt = $this->prepare($sql);
    $stmt->bind_param('iii', $setId, $courseId, $position);
    $stmt->execute();
    $stmt->close();
  }

  $data = array();
  $data["setId"] = $setId;
  $data["courseIds"] = $courseIds;
  return $data;
}

/********************************************************************************************
* insertOrUpdateUsers
********************************************************************************************/

public function insertOrUpdateUsers($users, $updated) {
  foreach ($users as $user) {
    $this->insertOrUpdateUser($user, $updated);
  }
}

/********************************************************************************************
* insertOrUpdateUser
********************************************************************************************/

public function insertOrUpdateUser($user, $updated) {
  $userId = $user['id'];
  $name = $user['name'];
  $loginId = $user['login_id'];
  $sisUserId = $user['sis_user_id'];
  $sisLoginId = $user['sis_login_id'];
  $studyRate = 300; /* 5 hours */
  $sql = 'insert into Users (userId, name, loginId, sisUserId, sisLoginId, studyRate, updated) values(?,?,?,?,?,?,?)'
    .' on duplicate key update name = ?, loginId = ?, sisUserId = ?, sisLoginId = ?, updated = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('isssssssssss', $userId, $name, $loginId, $sisUserId, $sisLoginId, $studyRate, $updated, $name, $loginId, $sisUserId, $sisLoginId, $updated);
  $stmt->execute();
  $stmt->close();
}

/********************************************************************************************
* selectUsers
********************************************************************************************/

public function selectUsers($where=null, $orderBy=null) {
  $sql = 'select userId, name, loginId, sisUserId, studyRate, updated from Users';
  if(isset($where)) {$sql = $sql.' '.$where;}
  if(isset($orderBy)) {$sql = $sql.' '.$orderBy;}
  else {$sql = $sql.' order by name asc';}
  $stmt = $this->prepare($sql);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($userid, $name, $loginId, $sisUserId, $studyRate, $updated);
  $data = array();
  while($stmt->fetch()) {
    $user = array();
    $user["userId"] = $userid;
    $user["name"] = $name;
    $user["loginId"] = $loginId;
    $user["sisUserId"] = $sisUserId;
    $user["studyRate"] = $studyRate;
    $user["updated"] = $updated;
    array_push($data, $user);
  }
  $stmt->close();
  return $data;
}

/********************************************************************************************
* selectUser
********************************************************************************************/

public function selectUser($userId) {
  $sql = 'select userId, name, loginId, sisUserId, studyRate, updated from Users where userId = ?';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $userId);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($userid, $name, $loginId, $sisUserId, $studyRate, $updated);
  if(!$stmt->fetch()){
    throw new Exception('No user found where userId ='.$userId, Status::NOT_FOUND);
  }
  $user = array();
  $user["userId"] = $userid;
  $user["name"] = $name;
  $user["loginId"] = $loginId;
  $user["sisUserId"] = $sisUserId;
  $user["studyRate"] = $studyRate;
  $user["updated"] = $updated;
  $stmt->close();
  return $user;
}

/********************************************************************************************
* selectCourseAssignmentItems
********************************************************************************************/

public function selectCourseAssignmentItems($courseId) {

  $sql = 'create temporary table if not exists temp as'
    .' (select i.name, i.itemid, i.duration, i.assignmentId'
    .' from Items as i join Modules as m on i.moduleid = m.moduleid'
    .' where i.courseid = ? order by m.position asc, i.position asc)';
  $stmt = $this->prepare($sql);
  $stmt->bind_param('i', $courseId);
  $stmt->execute();
  $stmt->close();
  
  $this->query('set @csum := 0;');

  $sql = 'create temporary table if not exists tmp as'
    .' (select itemId, name, duration, (@csum := @csum + duration) as elapsed, assignmentId from temp)';
  $stmt = $this->prepare($sql);
  $stmt->execute();
  $stmt->close();

  $sql = 'select itemId, name, duration, elapsed, assignmentId from tmp where assignmentid is not NULL';
  $stmt = $this->prepare($sql);
  $stmt->execute();
  $stmt->store_result();
  $stmt->bind_result($itemId, $name, $duration, $elapsed, $assignmentId);
  $data = array();
  while($stmt->fetch()) {
    $item = array();
    $item["itemId"] = $itemId;
    $item["name"] = $name;
    $item["duration"] = $duration;
    $item["elapsed"] = $elapsed;
    $item["assignmentId"] = $assignmentId;
    array_push($data, $item);
  }
  $stmt->close();
  return $data;
}

}
?>
