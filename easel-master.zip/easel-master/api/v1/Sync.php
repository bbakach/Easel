<?php // Sync.php

require_once("Canvas.php");
require_once("Database.php");
require_once("Status.php");

class Sync {

/********************************************************************************************
* handler
********************************************************************************************/

public static function handler($args) {

  $output = "";

  switch($_SERVER['REQUEST_METHOD']) {

    case 'DELETE':
      break;

    case 'GET':

      // sync
      if(count($args) == 0) {
      }

      // sync/users
      else if(count($args) == 1 && $args[0] == "users") {
        $updated = date("Y-m-d H:i:s");
        $canvas = new Canvas();
        $users = json_decode($canvas->users(), true);
        if(http_response_code() == Status::OK && count($users) > 0) {
          $GLOBALS["db"]->insertOrUpdateUsers($users, $updated);
        }
        $start = strtotime($updated);
        $finish = strtotime(date("Y-m-d H:i:s"));
        $duration = $finish - $start;
        $output = json_encode($duration, JSON_PRETTY_PRINT);
      }

      // sync/users/userId
      else if(count($args) == 2 && $args[0] == "users") {
        $updated = date("Y-m-d H:i:s");
        $canvas = new Canvas();
        $users = json_decode($canvas->users($args[1]), true);
        if(http_response_code() == Status::OK) {
          $GLOBALS["db"]->insertOrUpdateUsers($users, $updated);
        }
        $start = strtotime($updated);
        $finish = strtotime(date("Y-m-d H:i:s"));
        $duration = $finish - $start;
        $output = json_encode($duration, JSON_PRETTY_PRINT);
      }

      // sync/courses
      else if(count($args) == 1 && $args[0] == "courses") {
        $updated = date("Y-m-d H:i:s");
        $canvas = new Canvas();

        $accounts = json_decode($canvas->getAccounts(), true);
        if(http_response_code() == Status::OK && count($accounts) > 0) {
          $GLOBALS["db"]->insertOrUpdateAccounts($accounts, $updated);
        }

        $courses = json_decode($canvas->courses(), true);
        if(http_response_code() == Status::OK && count($courses) > 0) {
          $GLOBALS["db"]->insertOrUpdateCourses($courses, $updated);

          foreach ($courses as $course) {
            $modules = json_decode($canvas->modules($course['id']), true);
            if(http_response_code() == Status::OK && count($modules) > 0) {
              $GLOBALS["db"]->insertOrUpdateModules($course['id'], $modules, $updated);

              foreach ($modules as $module) {
                $items = json_decode($canvas->items($course['id'], $module['id']), true);
                if(http_response_code() == Status::OK && count($items) > 0) {

                  foreach ($items as $item) {
                  
                    $assignmentId = null;
                    
                    if($item["type"] == "Assignment") {
                      $assignmentId = $item["content_id"];
                    }
                   
                    else if($item["type"] == "Discussion") {
                      $assignmentId = $canvas->getDiscussionItemAssignmentId($course['id'], $item["content_id"]);
                    }

                    else if($item["type"] == "Quiz") {
                      $assignmentId = $canvas->getQuizItemAssignmentId($course['id'], $item["content_id"]);
                    }

                    $GLOBALS["db"]->insertOrUpdateItem($course['id'], $assignmentId, $item, $updated);

                  }
                }
              }
            }
          }
        }

        $GLOBALS["db"]->deleteOldAccounts($updated);
        $GLOBALS["db"]->deleteOldCourses($updated);
        $GLOBALS["db"]->deleteOldModules($updated);
        $GLOBALS["db"]->deleteOldItems($updated);

        $start = strtotime($updated);
        $finish = strtotime(date("Y-m-d H:i:s"));
        $duration = $finish - $start;
        $output = json_encode($duration, JSON_PRETTY_PRINT);
      }

      // sync/courses/courseId
      else if(count($args) == 2 && $args[0] == "courses") {
        $updated = date("Y-m-d H:i:s");
        $canvas = new Canvas();

        $accounts = json_decode($canvas->getAccounts(), true);
        if(http_response_code() == Status::OK && count($accounts) > 0) {
          $GLOBALS["db"]->insertOrUpdateAccounts($accounts, $updated);
        }

        $course = json_decode($canvas->courses($args[1]), true);
        if(http_response_code() == Status::OK) {

          $GLOBALS["db"]->insertOrUpdateCourse($course, $updated);

          $modules = json_decode($canvas->modules($course['id']), true);
          if(http_response_code() == Status::OK && count($modules) > 0) {
            $GLOBALS["db"]->insertOrUpdateModules($course['id'], $modules, $updated);

            foreach ($modules as $module) {
              $items = json_decode($canvas->items($course['id'], $module['id']), true);
              if(http_response_code() == Status::OK && count($items) > 0) {

                foreach ($items as $item) {
                  
                  $assignmentId = null;
                    
                  if($item["type"] == "Assignment") {
                    $assignmentId = $item["content_id"];
                  }
                   
                  else if($item["type"] == "Discussion") {
                    $assignmentId = $canvas->getDiscussionItemAssignmentId($course['id'], $item["content_id"]);
                  }

                  else if($item["type"] == "Quiz") {
                    $assignmentId = $canvas->getQuizItemAssignmentId($course['id'], $item["content_id"]);
                  }

                  $GLOBALS["db"]->insertOrUpdateItem($course['id'], $assignmentId, $item, $updated);

                }
              }
            }
          }
        }

        $GLOBALS["db"]->deleteOldAccounts($updated);
        $GLOBALS["db"]->deleteOldCourses($updated);
        $GLOBALS["db"]->deleteOldModules($updated);
        $GLOBALS["db"]->deleteOldItems($updated);

        $start = strtotime($updated);
        $finish = strtotime(date("Y-m-d H:i:s"));
        $duration = $finish - $start;
        $output = json_encode($duration, JSON_PRETTY_PRINT);
      }

      // sync/accounts
      /*
      else if(count($args) == 1 && $args[0] == "accounts") {
        $updated = date("Y-m-d H:i:s");
        $canvas = new Canvas();

        $users = json_decode($canvas->users(), true);
        if(http_response_code() == Status::OK && count($users) > 0) {
          $GLOBALS["db"]->insertOrUpdateUsers($users, $updated);
        }

        $accounts = json_decode($canvas->getAccounts(), true);
        if(http_response_code() == Status::OK && count($accounts) > 0) {
          $GLOBALS["db"]->insertOrUpdateAccounts($accounts, $updated);
        }

        $courses = json_decode($canvas->courses(), true);
        if(http_response_code() == Status::OK && count($courses) > 0) {
          $GLOBALS["db"]->insertOrUpdateCourses($courses, $updated);

          foreach ($courses as $course) {
            $modules = json_decode($canvas->modules($course['id']), true);
            if(http_response_code() == Status::OK && count($modules) > 0) {
              $GLOBALS["db"]->insertOrUpdateModules($course['id'], $modules, $updated);

              foreach ($modules as $module) {
                $items = json_decode($canvas->items($course['id'], $module['id']), true);
                if(http_response_code() == Status::OK && count($items) > 0) {

                  foreach ($items as $item) {
                  
                    $assignmentId = null;
                    
                    if($item["type"] == "Assignment") {
                      $assignmentId = $item["content_id"];
                    }
                   
                    else if($item["type"] == "Discussion") {
                      $assignmentId = $canvas->getDiscussionItemAssignmentId($course['id'], $item["content_id"]);
                    }

                    else if($item["type"] == "Quiz") {
                      $assignmentId = $canvas->getQuizItemAssignmentId($course['id'], $item["content_id"]);
                    }

                    $GLOBALS["db"]->insertOrUpdateItem($course['id'], $assignmentId, $item, $updated);

                  }
                }
              }
            }
          }
        }
        


        $GLOBALS["db"]->deleteOldAccounts($updated);
        $GLOBALS["db"]->deleteOldCourses($updated);
        $GLOBALS["db"]->deleteOldModules($updated);
        $GLOBALS["db"]->deleteOldItems($updated);

        $start = strtotime($updated);
        $finish = strtotime(date("Y-m-d H:i:s"));
        $duration = $finish - $start;
        $output = json_encode($duration, JSON_PRETTY_PRINT);

      }
      */
      else {
        $output = $args;
      }
      break;

    case 'POST':
      break;

    case 'PUT':
      break;

    default:
      http_response_code(Status::INTERNAL_SERVER_ERROR);
      break;
  }

  return $output;
}

}
?>