<?php // Accounts.php

require_once("Config.php");
require_once("Database.php");
require_once("Status.php");

class Accounts {

/********************************************************************************************
* handler
********************************************************************************************/

public static function handler($args) {

  $output = "";

  switch($_SERVER['REQUEST_METHOD']) {

    case 'DELETE':
      break;

    case 'GET':

      // accounts
      if(count($args) == 0) {
        $output = $GLOBALS["db"]->selectAccounts();
      }

      // accounts/accountId
      else if(count($args) == 1) {
        $output = $GLOBALS["db"]->selectAccount($args[0]);
      }

      // accounts/accountId/subaccounts
      else if(count($args) == 2 && $args[1] == "subaccounts") {
        $output = Accounts::getSubAccounts($args[0], $GLOBALS["db"]->selectAccounts());
      }

      // accounts/accountId/subaccounts/courses
      else if(count($args) == 3 && $args[1] == "subaccounts"&& $args[2] == "courses") {
        $output = Accounts::getSubAccountsAndCourses(Config::CANVAS_PARENT_ACCOUNT_ID, $GLOBALS["db"]->selectAccounts());
      }

      else {
        $output = $args;
      }
      break;

    case 'POST':
      break;

    case 'PUT':
      break;

    default:
      http_response_code(Status::INTERNAL_SERVER_ERROR);
      break;
  }

  return json_encode($output, JSON_PRETTY_PRINT);
}

/********************************************************************************************
* getSubAccounts
********************************************************************************************/

protected static function getSubAccounts($accountId, &$accounts) {
  $subAccounts = [];
  foreach ($accounts as $account) {
    if($account["parentId"] == $accountId) {
      $account["subAccounts"] = Accounts::getSubAccounts($account["accountId"], $accounts);
      array_push($subAccounts, $account);
    }
  }
  return $subAccounts;
}

/********************************************************************************************
* getSubAccountsAndCourses
********************************************************************************************/

protected static function getSubAccountsAndCourses($accountId, &$accounts) {
  $subAccounts = [];
  foreach ($accounts as $account) {
    if($account["parentId"] == $accountId) {
      $account["subAccounts"] = Accounts::getSubAccountsAndCourses($account["accountId"], $accounts);
      $account["courses"] = $GLOBALS["db"]->selectCourses("where accountId=".$account["accountId"]);
      array_push($subAccounts, $account);
    }
  }
  return $subAccounts;
}

}
?>
