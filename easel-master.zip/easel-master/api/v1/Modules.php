<?php // Modules.php

require_once("Database.php");
require_once("Status.php");

class Modules {

/********************************************************************************************
* handler
********************************************************************************************/

public static function handler($args) {

  $output = "";

  switch($_SERVER['REQUEST_METHOD']) {

    case 'DELETE':
      break;

    case 'GET':

      // modules/moduleId
      if(count($args) == 1) {
        $output = $GLOBALS["db"]->selectModule($args[0]);
      }
      
      // modules/moduleId/items
      else if(count($args) == 2 && $args[1] == "items") {
        $output = $GLOBALS["db"]->selectItems($args[0]);
      }

      // modules/moduleId/items/durations
      else if(count($args) == 3 && $args[1] == "items" && $args[2] == "durations") {
        $output = $GLOBALS["db"]->selectModuleItemDurationTotal($args[0]);
      }

      // modules/moduleId/items/itemId
      else if(count($args) == 3 && $args[1] == "items") {
        $output = $GLOBALS["db"]->selectItem($args[2]);
      }

      else {
        $output = $args;
      }
      break;

    case 'POST':
      break;

    case 'PUT':
      // modules/moduleId/duration
      if(count($args) == 2 && $args[1] == "duration") {
        $output = array();
        $moduleId = $args[0];
        $moduleDuration = Request::getData();
        $GLOBALS["db"]->updateModuleDuration($moduleId, $moduleDuration);
        $moduleItemDurationTotal = intval($GLOBALS["db"]->selectModuleItemDurationTotal($moduleId));
        $moduleReservoir = $moduleDuration - $moduleItemDurationTotal;
        $GLOBALS["db"]->updateModuleReservoir($moduleId, $moduleReservoir);
        $output["moduleReservoir"] = $moduleReservoir;
        $courseId = $GLOBALS["db"]->getCourseIdForModuleId($moduleId);
        $courseDuration = $GLOBALS["db"]->selectCourseDuration($courseId);
        $courseModuleDurationTotal = intval($GLOBALS["db"]->selectCourseModuleDurationTotal($courseId));
        $courseReservoir = $courseDuration - $courseModuleDurationTotal;
        $GLOBALS["db"]->updateCourseReservoir($courseId, $courseReservoir);
        $output["courseReservoir"] = $courseReservoir;
      }

      else {
        $output = $args;
      }
      break;

    default:
      http_response_code(Status::INTERNAL_SERVER_ERROR);
      break;
  }

  return json_encode($output, JSON_PRETTY_PRINT);
}

}
?>