<?php // Test.php

require_once("Database.php");
require_once("Status.php");

class Test {

/********************************************************************************************
* handler
********************************************************************************************/

public static function handler($args) {

  switch($_SERVER['REQUEST_METHOD']) {

    case 'DELETE':
      break;

    case 'GET':
      if(count($args) == 1 && $args[0] == "datetime") {
        return json_encode(date('Y-m-d H:i:s'), JSON_PRETTY_PRINT);
      }

      else if(count($args) == 1 && $args[0] == "string") {
        return json_encode('This is a test', JSON_PRETTY_PRINT);
      }

      else if(count($args) == 1 && $args[0] == "method") {
        return json_encode(Request::getMethod(), JSON_PRETTY_PRINT);
      }

      else if(count($args) == 1 && $args[0] == "courseduration") {
        $db = new Database();
        $val = $db->selectCourseDuration(9);
        return json_encode($val, JSON_PRETTY_PRINT);
      }

      else if(count($args) == 1 && $args[0] == "authenticate") {
        $db = new Database();
        return $db->authenticate();
      }

      break;

    case 'POST':
      break;

    case 'PUT':
      break;

    default:
      http_response_code(Status::INTERNAL_SERVER_ERROR);
      break;
  }

  return json_encode($output, JSON_PRETTY_PRINT);
}

}
?>