<?php

require_once("Config.php");
  
class Peer {

public $curl = "";
public $response = "";
public $err = "";

/********************************************************************************************
* construct
********************************************************************************************/

public function __construct(){
  $this->curl = curl_init();
}

/********************************************************************************************
* destruct
********************************************************************************************/

function __destruct() {
  curl_close($this->curl);
}

/********************************************************************************************
* delete
********************************************************************************************/

public function delete($url){
  curl_setopt_array(
    $this->curl, 
    array(
      CURLOPT_URL => Config::CANVAS_URL.$url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "DELETE",
      CURLOPT_HTTPHEADER => array(
        "authorization: Bearer ".$GLOBALS["admin"]["authcode"], 
        "cache-control: no-cache"
      )
    )
  );

  $this->response = curl_exec($this->curl);
  $this->err = curl_error($this->curl);

  if ($this->err) {return false;}
  else {return true;}
}

/********************************************************************************************
* get
********************************************************************************************/

public function get($url){
  curl_setopt_array(
    $this->curl, 
    array(
      CURLOPT_URL => Config::CANVAS_URL.$url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_HTTPHEADER => array(
        "authorization: Bearer ".$GLOBALS["admin"]["authcode"], 
        "cache-control: no-cache"
      )
    )
  );

  $this->response = curl_exec($this->curl);
  $this->err = curl_error($this->curl);

  if ($this->err) {return false;}
  else {return true;}
}

/********************************************************************************************
* getWithParms
********************************************************************************************/

public function getWithParms($url, $data){
  curl_setopt_array(
    $this->curl, 
    array(
      CURLOPT_URL => Config::CANVAS_URL.$url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_HTTPHEADER => array(
        "authorization: Bearer ".$GLOBALS["admin"]["authcode"], 
        "cache-control: no-cache",
        "content-type: multipart/form-data; boundary=MMM"
      ),
      CURLOPT_POSTFIELDS => $data
    )
  );

  $this->response = curl_exec($this->curl);
  $this->err = curl_error($this->curl);

  if ($this->err) {return false;}
  else {return true;}
}

/********************************************************************************************
* post
********************************************************************************************/

public function post($url, $data){
  curl_setopt_array(
    $this->curl, 
    array(
      CURLOPT_URL => Config::CANVAS_URL.$url,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_HTTPHEADER => array(
        "authorization: Bearer ".$GLOBALS["admin"]["authcode"], 
        "cache-control: no-cache",
        "content-type: multipart/form-data; boundary=MMM"
      ),
      CURLOPT_POSTFIELDS => $data
      /*
      CURLOPT_POSTFIELDS => ""
        ."--MMM\r\nContent-Disposition: form-data; name=\"assignment_override[student_ids][]\"\r\n\r\n48\r\n"
        ."--MMM\r\nContent-Disposition: form-data; name=\"assignment_override[title]\"\r\n\r\nJoe Hagen\r\n"
        ."--MMM\r\nContent-Disposition: form-data; name=\"assignment_override[due_at]\"\r\n\r\n2017-02-30T00:00:00Z\r\n"
        ."--MMM--"
      */
    )
  );

  $this->response = curl_exec($this->curl);
  $this->err = curl_error($this->curl);

  if ($this->err) {return false;}
  else {return true;}
}

}  
?>