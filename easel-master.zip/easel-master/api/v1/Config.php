<?php // Config.php

class Config {
  const DB_HOSTNAME = "";	
  const DB_USERNAME = "";	
  const DB_PASSWORD = "";
  const DB_NAME = "";
  const CANVAS_URL = "";
  const CANVAS_ACCOUNT_ID = 1;
  const CANVAS_PARENT_ACCOUNT_ID = 0;
}

?>
