<?php // Sets.php

require_once("Database.php");
require_once("Request.php");
require_once("Status.php");

class Sets {

/********************************************************************************************
* handler
********************************************************************************************/

public static function handler($args) {

  $output = array();

  switch($_SERVER['REQUEST_METHOD']) {

    case 'DELETE':

      // sets/setId
      if(count($args) == 1) {
        $setId = (int)$args[0];
        $GLOBALS["db"]->deleteSet($setId);
        Sets::deleteSubsets($setId, $output);
      }

      else {
        $output = $args;
      }
      break;

    case 'GET':

      // sets
      if(count($args) == 0) {
        $output = $GLOBALS["db"]->selectSets();
      }

      // sets/setId
      else if(count($args) == 1) {
        $output = $GLOBALS["db"]->selectSet($args[0]);
      }

      // sets/setId/subsets
      else if(count($args) == 2 && $args[1] == "subsets") {
        $output = Sets::getSubsets($args[0], $GLOBALS["db"]->selectSets());
      }

      // sets/setId/courses
      else if(count($args) == 2 && $args[1] == "courses") {
        $output = $GLOBALS["db"]->selectSetCourses($args[0]);
      }

      // sets/setId/subsets/courses
      else if(count($args) == 3) {
        $output = Sets::getSubsetsAndCourses($args[0], $GLOBALS["db"]->selectSets());
      }

      else {
        $output = $args;
      }
      break;

    case 'POST':

      // sets
      if(count($args) == 0) {
        $input = Request::getData();
        $output = $GLOBALS["db"]->createSet($input);
      }

      else {
        $output = $args;
      }
      break;

    case 'PUT':

      // sets/setId
      if(count($args) == 1) {
        $input = Request::getData();
        $output = $GLOBALS["db"]->insertOrUpdateSet($input['setId'], $input);
      }

      // sets/setId/name
      else if(count($args) == 2 && $args[1] == "name") {
        $name = Request::getData();
        $output = $GLOBALS["db"]->updateSetName($args[0], $name);
      }

      // sets/setId/duration
      else if(count($args) == 2 && $args[1] == "duration") {
        $duration = Request::getData();
        $output = $GLOBALS["db"]->updateSetDuration($args[0], $duration);
      }

      else {
        $output = $args;
      }
      break;

    case 'LINK':

      // sets/setId/courses
      if(count($args) == 2 && $args[1] == "courses") {
        $courseIds = Request::getData();
        $output = $GLOBALS["db"]->relateSetAndCourses($args[0], $courseIds);
      }

      else {
        $output = $args;
      }
      break;

    case 'UNLINK':
      break;

    default:
      http_response_code(Status::INTERNAL_SERVER_ERROR);
      break;
  }

  return json_encode($output, JSON_PRETTY_PRINT);
}

/********************************************************************************************
* deleteSubsets
********************************************************************************************/

protected static function deleteSubsets($parentId, &$output) {
  array_push($output, $parentId);
  $subsets = $GLOBALS["db"]->selectSets("where parentId=".$parentId);
  $GLOBALS["db"]->deleteSets("where parentId=".$parentId);
  foreach($subsets as $subset) {
    Sets::deleteSubsets($subset["setId"], $output);
  }
}

/********************************************************************************************
* getSubsets
********************************************************************************************/

protected static function getSubsets($setId, &$sets) {
  $subsets = [];
  foreach ($sets as $set) {
    if($set["parentId"] == $setId) {
      $set["subsets"] = Sets::getSubsets($set["setId"], $sets);
      array_push($subsets, $set);
    }
  }
  return $subsets;
}

/********************************************************************************************
* getSubsetsAndCourses
********************************************************************************************/

protected static function getSubsetsAndCourses($setId, &$sets) {
  $subsets = [];
  foreach ($sets as $set) {
    if($set["parentId"] == $setId) {
      $set["subsets"] = Sets::getSubsetsAndCourses($set["setId"], $sets);
      $set["courses"] = $GLOBALS["db"]->selectSetCourses($set["setId"]);
      array_push($subsets, $set);
    }
  }
  return $subsets;
}

}
?>