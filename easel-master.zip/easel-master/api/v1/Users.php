<?php // Users.php

require_once("Canvas.php");
require_once("Database.php");
require_once("Request.php");
require_once("Status.php");

class Users {

/********************************************************************************************
* handler
********************************************************************************************/

public static function handler($args) {

  $output = array();

  switch($_SERVER['REQUEST_METHOD']) {

    case 'DELETE':
      $output = json_encode(array("Not Implemented"), JSON_PRETTY_PRINT);
      http_response_code(Status::NOT_IMPLEMENTED);
      break;

    case 'GET':

      // users
      if(count($args) == 0) {
        $output = json_encode($GLOBALS["db"]->selectUsers(), JSON_PRETTY_PRINT);
      }
      
      // users/authenticate
      // Remember to add "CGIPassAuth on" to .htaccess.
      else if(count($args) == 1 && $args[0] == "authenticate") {
        $output = json_encode($GLOBALS["user"], JSON_PRETTY_PRINT);
      }

      // users/userId
      else if(count($args) == 1) {
        $output = json_encode($GLOBALS["db"]->selectUser($args[0]), JSON_PRETTY_PRINT);
      }

      // users/userId/courses
      else if(count($args) == 2 && $args[1] == "courses") {
        $canvas = new Canvas();
        $canvasCourses = json_decode($canvas->userCourses($args[0]), true);
        $courses = array();
        foreach ($canvasCourses as $canvasCourse) {
          $course = array();
          $course["courseId"] = $canvasCourse["id"];
          $course["name"] = $canvasCourse["name"];
          $course["duration"] = $GLOBALS["db"]->selectCourseDuration($canvasCourse["id"]);
          array_push($courses, $course);
        }

        usort($courses, "Users::sortArrayByName");

        $output = json_encode($courses, JSON_PRETTY_PRINT);
      }

      else {
        $output = $args;
      }
      break;

    case 'POST':
      $output = json_encode(array("Not Implemented"), JSON_PRETTY_PRINT);
      http_response_code(Status::NOT_IMPLEMENTED);
      break;

    case 'PUT':
      $output = json_encode(array("Not Implemented"), JSON_PRETTY_PRINT);
      http_response_code(Status::NOT_IMPLEMENTED);
      break;

    default:
      $output = json_encode(array("Not Implemented"), JSON_PRETTY_PRINT);
      http_response_code(Status::NOT_IMPLEMENTED);
      break;
  }

  return $output;
}

/********************************************************************************************
* sortArrayByName
********************************************************************************************/

public static function sortArrayByName($a, $b) {return strcmp($a['name'], $b['name']);}

}
?>