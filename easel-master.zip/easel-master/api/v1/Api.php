<?php // Api.php
require_once("Accounts.php");
require_once("Canvas.php");
require_once("Config.php");
require_once("Courses.php");
require_once("Database.php");
require_once("Items.php");
require_once("Modules.php");
require_once("Request.php");
require_once("Sets.php");
require_once("Status.php");
require_once("Sync.php");
require_once("Test.php");
require_once("Users.php");

http_response_code(Status::OK);

try {

  $db = new Database(Config::DB_HOSTNAME, Config::DB_USERNAME, Config::DB_PASSWORD, Config::DB_NAME);
  $admin = $db->authenticate();

  if($admin["adminId"] == 0) {
    http_response_code(Status::UNAUTHORIZED);
    echo json_encode(Status::message(Status::UNAUTHORIZED), JSON_PRETTY_PRINT);
    return;
  }

  $args = explode('/', strtolower(trim($_REQUEST['function'])));
  if(count($args) == 0) {
    http_response_code(Status::INTERNAL_SERVER_ERROR);
    echo json_encode(Status::message(Status::INTERNAL_SERVER_ERROR), JSON_PRETTY_PRINT);
    return;
  }

  echo $args[0]::handler(array_slice($args, 1));
  return;

} catch(Exception $ex) {

  http_response_code(Status::INTERNAL_SERVER_ERROR);
  echo json_encode(Status::message(Status::INTERNAL_SERVER_ERROR), JSON_PRETTY_PRINT);
  return;

}
?>