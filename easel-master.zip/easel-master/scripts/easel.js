var easelUrl = '';
//var canvasUrl = '';
var credentials = '';
var authenticated = 0;

//*********************************************
// navigation and login handlers
//*********************************************

$(document).ready(function() {

  easelUrl = location.origin + location.pathname + "api/v1";

  $('#home-item').on('click', function(event) {
    changePage(event, this, $('#home-page'));
  });

  $('#assignments-item').on('click', function(event) {
    if(changePage(event, this, $('#assignments-page'))) {
    }
  });

  $('#durations-item').on('click', function(event) {
    if(changePage(event, this, $('#durations-page'))) {
    }
  });

  $('#tables-item').on('click', function(event) {
    if(changePage(event, this, $('#tables-page'))) {
    }
  });

  $('#sync-item').on('click', function(event) {
    changePage(event, this, $('#sync-page'));
  });

  $('#test-item').on('click', function(event) {
    changePage(event, this, $('#test-page'));
  });

  $('#login-button').on('click', function(event) {
    getPermission(showError);
  });

  $('#logout-button').on('click', function(event) {
    authenticated = 0;
    $(".logout").addClass("hidden");
    $(".login").removeClass("hidden");    
  });

});

/**********************************************
* changePage
**********************************************/

function changePage(event, listItem, newPage) {
  event.preventDefault();
  if(authenticated) {
    $(listItem).addClass('active');
    $(listItem).siblings().removeClass('active');
    $(newPage).removeClass('hidden');
    $(newPage).siblings().addClass('hidden');
    return true;
  } else {
    return false;
  }
}

//*********************************************
// initDurationsPage
//*********************************************

function initDurationsPage() {

  if($("#durations-page .mix-column > ul > li").length == 0) {
    getSubsetsAndCourses(showSubsetsAndCourses, showError);
  }

  if($("#durations-page .can-column > ul > li").length == 0) {
    getSubAccountsAndCourses(showSubAccountsAndCourses, showError);
  }

}

//*********************************************
// showSubsetsAndCourses
//*********************************************

var showSubsetsAndCourses = function(data) {
  $('#durations-page .mix-column ul').empty();
  showSubsetsAndCoursesHierarchy(data, $('#durations-page .mix-column ul'));
  enableSortable();
}

//*********************************************
// showSubsetsAndCoursesHierarchy
//*********************************************

function showSubsetsAndCoursesHierarchy(sets, list) {

  for(var i=0; i < sets.length; i++) {
    var set = sets[i];

    $(list).append(createSetListItem(set));
    var setLI = $(list).children("li").last();
    var setLIList = $(setLI).children("ul");

    var courses = set.courses;
    // var duration = 0;
    for(var j=0; j < courses.length; j++) {
      $(setLIList).append(createSetCourseListItem(courses[j]));
      // duration += courses[j].duration;
    }
    // if(duration == 0) {duration = "";}
    // $(setLI).children("div.folder").children("input.duration").val(toSTime(duration));

    showSubsetsAndCoursesHierarchy(set.subsets, setLIList);
  }
}

//*********************************************
// showSubAccountsAndCourses
//*********************************************

var showSubAccountsAndCourses = function(data) {
  $('#durations-page .can-column ul').empty();
  showSubAccountsAndCoursesHierarchy(data, $('#durations-page .can-column ul'));
  enableDraggable($("#durations-page .can-column").find("div.course"));
}

//*********************************************
// showSubAccountsAndCoursesHierarchy
//*********************************************

function showSubAccountsAndCoursesHierarchy(accounts, list) {
  for(var i=0; i < accounts.length; i++) {
    var account = accounts[i];
    var accountLI = createAccountListItem(account);
    var courses = account.courses;
    for(var j=0; j < courses.length; j++) {
      $(accountLI).children("ul").append(createAccountCourseListItem(courses[j]));
    }
    showSubAccountsAndCoursesHierarchy(account.subAccounts, $(accountLI).children("ul"));
    $(list).append(accountLI);
  }
}

//*********************************************
// showModules
//*********************************************

var showModules = function(data) {
  for(var i=0; i < data.length; i++) {
    var listItem = createModuleListItem(data[i]);
    $(this.list).append(listItem);
  }
}

//*********************************************
// showItems
//*********************************************

var showItems = function(data) {
  for(var i=0; i < data.length; i++) {
    var listItem = createItemListItem(data[i]);
    $(this.list).append(listItem);
  }
}

//*********************************************
// createSetListItem
//*********************************************

function createSetListItem(data) {
  var reservoir = data.reservoir;
  //if(reservoir==0) {reservoir="";}

  //var duration = data.duration;
  //if(duration == 0) {duration = "";}

  var listItemStr = ''
    + '<li data-setId = "' + data.setId + '">'
    + '<div class="tile folder">'
    + '<span class="glyphicon glyphicon-folder-close open-close"></span>'
    + '<input class="title" value="' + data.name + '"></input>'
    + '<span class="glyphicon glyphicon-option-horizontal option-dots pull-right"></span>'
    + '<input class="duration pull-right" value="' + toSTime(data.duration) + '"></input>'
    + '<input class="reservoir pull-right" value="' + toSTime(reservoir) + '" disabled></input>'
    + '</div>'
    + '<ul class="hidden"></ul>'
    + '</li>';
  return listItemStr;
}

//*********************************************
// createAccountListItem
//*********************************************

function createAccountListItem(data) {
  var listItem = ''
    + '<li data-accountId = "' + data.accountId + '">'
    + '<div class="tile folder">'
    + '<span class="glyphicon glyphicon-folder-close open-close"></span>'
    + '<span class="title">' + data.name.substring(0,50) + '</span>'
    + '<span class="glyphicon glyphicon-option-horizontal option-dots pull-right"></span>'
    + '</div>'
    + '<ul class="hidden"></ul>'
    + '</li>';
  return $.parseHTML(listItem);
}

//*********************************************
// createSetCourseListItem
//*********************************************

function createSetCourseListItem(data) {
  var listItem = ''
    + '<li data-courseId = "' + data.courseId + '">'
    + '<div class="tile course">'
    + '<span class="glyphicon glyphicon-book"></span>'
    + '<span class="title">' + data.name.substring(0,50) + '</span>'
    + '<span class="glyphicon glyphicon-option-horizontal option-dots pull-right"></span>'
    + '<input class="duration pull-right" value="' + toSTime(data.duration) + '" disabled></input>'
    + '</div>'
    + '<ul class="hidden"></ul>'
    + '</li>';
  return $.parseHTML(listItem);
}

//*********************************************
// createAccountCourseListItem
//*********************************************

function createAccountCourseListItem(data) {
  var reservoir = data.reservoir;
  //if(reservoir==0) {reservoir="";}

  var listItem = ''
    + '<li data-courseId = "' + data.courseId + '">'
    + '<div class="tile course">'
    + '<span class="glyphicon glyphicon-book"></span>'
    + '<span class="title">' + data.name.substring(0,50) + '</span>'
    + '<span class="glyphicon glyphicon-option-horizontal option-dots pull-right"></span>'
    + '<input class="duration pull-right" value="' + toSTime(data.duration) + '" ></input>'
    + '<input class="reservoir pull-right" value="' + toSTime(reservoir) + '" disabled></input>'
    + '</div>'
    + '<ul class="hidden"></ul>'
    + '</li>';
  return $.parseHTML(listItem);
}

//*********************************************
// createModuleListItem
//*********************************************

function createModuleListItem(data) {
  var reservoir = data.reservoir;
  //if(reservoir==0) {reservoir="";}

  var listItem = ''
    + '<li data-moduleId = "' + data.moduleId + '">'
    + '<div class="tile module">'
    + '<span class="glyphicon glyphicon-file"></span>'
    + '<span class="title">' + data.name.substring(0,50) + '</span>'
    + '<span class="glyphicon glyphicon-option-horizontal option-dots pull-right"></span>'
    + '<input class="duration pull-right" value="' + toSTime(data.duration) + '" ></input>'
    + '<input class="reservoir pull-right" value="' + toSTime(reservoir) + '" disabled></input>'
    + '</div>'
    + '<ul class="hidden"></ul>'
    + '</li>';
  return $.parseHTML(listItem);
}

//*********************************************
// createItemListItem
//*********************************************

function createItemListItem(data) {
  var listItem = ''
    + '<li'
    + ' data-itemId = "' + data.itemId + '"'
    + ' data-contentType = "' + data.contentType + '"'
    + ' data-assignmentId = "' + data.assignmentId + '"'
    + '>'
    + '<div class="tile item">'
    + '<span class="glyphicon glyphicon-leaf"></span>'
    + '<span class="title">' + data.name.substring(0,50) + '</span>'
    + '<span class="glyphicon glyphicon-option-horizontal option-dots pull-right"></span>'
    + '<input class="duration pull-right" value="' + toSTime(data.duration) + '"></input>'
    + '</div>'
    + '</li>';
  return $.parseHTML(listItem);
}

//*********************************************
// enableSortable
//*********************************************

function enableSortable() {
  var lists = $("#durations-page .mix-column").find("ul");

  $(lists).sortable({
    forcePlaceholderSize: true,
    items: "> li",
    placeholder: 'placeholder',
    revert: true,
    
    stop:  function(event, ui) {
      var tile = ui.item.children(".tile");    
      if($(tile).hasClass("ui-draggable")) {
        var courseId = ui.item.data("courseid");
        var courses = ui.item.parent("ul").children("li.ui-sortable-handle");
        var courseIds = [];         
        for (var i = 0; i < courses.length; i++) {
          courseIds.push($(courses[i]).data("courseid"));
        }
        if(jQuery.inArray(courseId, courseIds) == -1) {
          $(tile).removeAttr('style');  
          $(tile).removeClass('ui-draggable');
          $(tile).removeClass('ui-draggable-handle');
          ui.item.removeAttr('style');
          ui.item.addClass('ui-sortable-handle');
          linkSetAndCourses(ui.item.parent("ul").parent("li"), showNothing, showError);     
        } else {
          alert("This course is already a member of this set.");
          ui.item.remove();
        }
      } else {
        linkSetAndCourses(ui.item.parent("ul").parent("li"), showNothing, showError);
      }
    }
  });
}

//*********************************************
// enableDraggable
//*********************************************

function enableDraggable(tiles) {
  $(tiles).draggable({
    cancel: ".noselect",
    cursorAt: false,
    connectToSortable: "#durations-page .mix-column > ul ul",
    disabled: false,
    helper: function() {
      var listItem = $(this).closest("li");
      var courseId = $(listItem).data("courseid");
      var tile = $(this).clone();
      var optionDots = $(tile).find(".option-dots");
      if($(optionDots).hasClass("glyphicon-option-vertical")) {
        $(optionDots).removeClass('glyphicon-option-vertical').addClass('glyphicon-option-horizontal');
      }
      $(tile).children(".duration").prop('disabled', true);
      $(tile).children(".reservoir").remove();
      return $('<li data-courseId=' + courseId + ' style="width: ' + $(this).css("width") + '; height: 36px; z-index: 500;">').append(tile);
    },
    revert: "invalid",
    scroll: true
  });
}

//*********************************************
// disableDraggable
//*********************************************

function disableDraggable(tiles) {
  $(tiles).draggable( "disable" );
}

//*********************************************
// durations-page handlers
//*********************************************

$(document).ready(function() {

  $("#durations-page").delegate(".expand-all-folders", "click", function(e) {
    var lists = $(this).closest('div').find('div.folder').siblings('ul.hidden');
    expandAllFolders(lists);
  });

  $("#durations-page").delegate(".collapse-all-folders", "click", function(e) {
    var lists = $(this).closest('div').children('ul').children('li').find('ul');
    collapseAllFolders(lists);
  });

  $("#durations-page").delegate(".new-set", "click", function(e) {
    var list = $('#durations-page .mix-column > ul');
    var set = new Object();
    set.name = "New Set";
    set.abbrev = "NS";
    set.duration = 0;
    set.parentId = 0;
    set.reservoir = 0;
    set.position = 0;
    postSet(set, list, showSet, showError);
  });

  $("#durations-page").delegate(".glyphicon-folder-close", "click", function(e) {
    expandFolder($(this).closest("li"));
  });

  $("#durations-page").delegate(".glyphicon-folder-open", "click", function(e) {
    collapseFolder($(this).closest("li"));
  });

  $("#durations-page").delegate(".can-column .glyphicon-book", "click", function(e) {
    var list = $(this).closest("li").children("ul");
    if($(list).hasClass("hidden")) {
      if($(list).children().length == 0) {
        var courseId = $(this).closest("li").data('courseid');
        getModules(courseId, list, showModules, showError);
      }
      $(list).removeClass("hidden");
    }
    else {
      $(list).addClass("hidden");
    }
  });

  $("#durations-page").delegate(".can-column .glyphicon-file", "click", function(e) {
    var list = $(this).closest("li").children("ul");
    if($(list).hasClass("hidden")) {
      if($(list).children().length == 0) {
        var moduleId = $(this).closest("li").data('moduleid');
        getItems(moduleId, list, showItems, showError);
      }
      $(list).removeClass("hidden");
    }
    else {
      $(list).addClass("hidden");
    }
  });

});

//*********************************************
// showSet
//*********************************************

var showSet = function(data) {
  var listItem = createSetListItem(data);
  $(this.list).prepend(listItem);
  enableSortable();
}

//*********************************************
// Options handlers
//*********************************************

$(document).ready(function() {

  $("#durations-page").delegate(".mix-column .folder .glyphicon-option-horizontal", "click", function(e) {
    $(this).removeClass('glyphicon-option-horizontal').addClass('glyphicon-option-vertical');
    $(this).parent().after(''
      + '<div class="edit">'
      + '<p class="pull-left">Set ID = ' + $(this).closest("li").data("setid") + '</p>'
      + '<button id="" class="btn btn-default btn-sm add-subset pull-right">+ Subset</button>'
      + '<button id="" class="btn btn-default btn-sm delete-set pull-right">Delete</button>'
      + '</div>'
    );
  });

  $("#durations-page").delegate(".edit .delete-set", "click", function(e) {
    var listItem = $(this).closest("li");
    var setId = $(listItem).data("setid");
    $(listItem).remove();
    deleteSet(setId, showNothing, showError);
  });

  $("#durations-page").delegate(".edit .add-subset", "click", function(e) {
    var listItem = $(this).closest("li");
    expandFolder(listItem);
    var list = $(listItem).children("ul");
    var set = new Object();
    set.name = "New Set";
    set.abbrev = "NS";
    set.parentId = $(listItem).data("setid");
    set.position = 0;
    set.duration = 0;
    set.reservoir = 0;
    postSet(set, list, showSet, showError);
    hideOptionWindow(listItem);
  });

  $("#durations-page").delegate(".mix-column .course .glyphicon-option-horizontal", "click", function(e) {
    $(this).removeClass('glyphicon-option-horizontal').addClass('glyphicon-option-vertical');
    $(this).parent().after(''
      + '<div class="edit">'
      + '<p class="pull-left">Course ID = ' + $(this).closest("li").data("courseid") + '</p>'
      + '<button id="" class="btn btn-default btn-sm remove-course pull-right">Remove</button>'
      + '</div>'
    );
  });

  $("#durations-page").delegate(".edit .remove-course", "click", function(e) {
    var listItem = $(this).closest("li");
    var parentListItem = $(listItem).parent("ul").parent("li");
    $(listItem).remove();
    linkSetAndCourses(parentListItem, showNothing, showError);
  });

  $("#durations-page").delegate(".can-column .folder .glyphicon-option-horizontal", "click", function(e) {
    showOptionWindowWithId("Account", $(this).closest("li").data("accountid"), this);
  });

  $("#durations-page").delegate(".can-column .course .glyphicon-option-horizontal", "click", function(e) {
    $(this).removeClass('glyphicon-option-horizontal').addClass('glyphicon-option-vertical');
    $(this).parent().after(''
      + '<div class="edit">'
      + '<p class="pull-left">Course ID = ' + $(this).closest("li").data("courseid") + '</p>'
      + '<button id="" class="btn btn-default btn-sm initialize-course-durations pull-right">Initialize Durations</button>'
      + '</div>'
    );
  });

  $("#durations-page").delegate(".edit .initialize-course-durations", "click", function(e) {
    var listItem = $(this).closest("li");
    var courseId = $(listItem).data("courseid");
    putCourseDurations(courseId, listItem, showInitializedCourseDurations, showError);
  });

  $("#durations-page").delegate(".can-column .module .glyphicon-option-horizontal", "click", function(e) {
    // showOptionWindowWithId("Module", $(this).closest("li").data("moduleid"), this);
    $(this).removeClass('glyphicon-option-horizontal').addClass('glyphicon-option-vertical');
    $(this).parent().after(''
      + '<div class="edit">'
      + '<p class="">Course ID = ' + $(this).closest("li").parent("ul").closest("li").data("courseid") + '</p>'
      + '<p class="">Module ID = ' + $(this).closest("li").data("moduleid") + '</p>'
      + '</div>');
  });

  $("#durations-page").delegate(".can-column .item .glyphicon-option-horizontal", "click", function(e) {
    $(this).removeClass('glyphicon-option-horizontal').addClass('glyphicon-option-vertical');
    $(this).parent().after(''
      + '<div class="edit">'
      + '<p class="">Course ID = ' + $(this).closest("li").parent("ul").closest("li").parent("ul").closest("li").data("courseid") + '</p>'
      + '<p class="">Module ID = ' + $(this).closest("li").parent("ul").closest("li").data("moduleid") + '</p>'
      + '<p class="">Item ID = ' + $(this).closest("li").data("itemid") + '</p>'
      + '<p class="">Content Type = ' + $(this).closest("li").data("contenttype") + '</p>'
      + '<p class="">Assignment ID = ' + $(this).closest("li").data("assignmentid") + '</p>'
      + '</div>');
  });

  $("#durations-page").delegate(".glyphicon-option-vertical", "click", function(e) {
    hideOptionWindow($(this).closest("li"));
  });

});

function showOptionWindowWithId(objectName, objectId, span) {
  $(span).removeClass('glyphicon-option-horizontal').addClass('glyphicon-option-vertical');
  $(span).parent().after('<div class="edit"><p class="pull-left">' + objectName + ' ID = ' + objectId + '</p></div>');
}

function showEmptyOptionWindow(span) {
  $(span).removeClass('glyphicon-option-horizontal').addClass('glyphicon-option-vertical');
  $(span).parent().after('<div class="edit"></div>');
}

function hideOptionWindow(listItem) {
  $(listItem).find(".option-dots").removeClass('glyphicon-option-vertical').addClass('glyphicon-option-horizontal');
  $(listItem).children('div.edit').remove();
}

//*********************************************
// input handlers
//*********************************************

$(document).ready(function() {

  $("#durations-page").delegate(".mix-column li div.tile", "click", function(e) {
    if (e.target === this) {
      $(this).focus();
    }
  });

  $("#durations-page").delegate(".mix-column .folder input.title", "click", function(e) {
    $(this).data("oldvalue", $(this).val());
    $(this).select();
  });

  $("#durations-page").delegate(".mix-column .folder input.title", "keydown", function(e) {
    if(e.which == 13) {
      e.preventDefault();
      var listItem = $(this).closest("li");
      var setId = $(listItem).data("setid");
      var name = $(this).val();
      putSetName(setId, name, showNothing, showError);
      $(this).blur();
    } else if(e.which == 27) {
      e.preventDefault();
      $(this).val($(this).data("oldvalue"));
      $(this).blur();
    }
  });

  $("#durations-page").delegate(".mix-column .folder input.duration", "click", function(e) {
    $(this).select();
  });

  $("#durations-page").delegate(".mix-column .folder input.duration", "keydown", function(e) {
    if(e.which == 13) {
      e.preventDefault();
      var listItem = $(this).closest("li");
      var setId = $(listItem).data("setid");
      var duration = toITime($(this).val());
      putSetDuration(setId, duration, showNothing, showError);
      $(this).blur();
    } else if(e.which == 27) {
      e.preventDefault();
      $(this).blur();
    }
  });

  $("#durations-page").delegate(".can-column .course input.duration", "click", function(e) {
    disableDraggable($(this).parent());
    $(this).focus().select();
  });

  $("#durations-page").delegate(".can-column .course input.duration", "keydown", function(e) {
    if(e.which == 13) {
      e.preventDefault();
      var listItem = $(this).closest("li");
      var courseId = $(listItem).data("courseid");
      var duration = toITime($(this).val());
      putCourseDuration(courseId, listItem, duration, showUpdatedCourseDuration, showError);
      $(this).blur();
    } else if(e.which == 27) {
      e.preventDefault();
      $(this).blur();
    }
  });

  $("#durations-page").delegate(".can-column .course input.duration", "focusout", function(e) {
    enableDraggable($(this).parent());
  });

  $("#durations-page").delegate(".can-column .module input.duration", "click", function(e) {
    $(this).focus().select();
  });

  $("#durations-page").delegate(".can-column .module input.duration", "keydown", function(e) {
    if(e.which == 13) {
      e.preventDefault();
      var listItem = $(this).closest("li");
      var moduleId = $(listItem).data("moduleid");
      var duration = toITime($(this).val());
      // alert("Module ID = " + moduleId + ", Duration = " + duration);
      putModuleDuration(moduleId, listItem, duration, showUpdatedModuleDuration, showError);
      $(this).blur();
    } else if(e.which == 27) {
      e.preventDefault();
      $(this).blur();
    }
  });
  $("#durations-page").delegate(".can-column .item input.duration", "click", function(e) {
    $(this).focus().select();
  });

  $("#durations-page").delegate(".can-column .item input.duration", "keydown", function(e) {
    if(e.which == 13) {
      e.preventDefault();
      var listItem = $(this).closest("li");
      var itemId = $(listItem).data("itemid");
      var duration = toITime($(this).val());
      putItemDuration(itemId, listItem, duration, showUpdatedItemDuration, showError);
      $(this).blur();
    } else if(e.which == 27) {
      e.preventDefault();
      $(this).blur();
    }
  });

});

//*********************************************
// showInitializedCourseDurations
//*********************************************

var showInitializedCourseDurations= function(data) {  
  // alert(JSON.stringify(data));

  $(this.listItem).children("div.course").children("input.reservoir").val(toSTime(data.courseReservoir));
  var moduleList = $(this.listItem).children("ul");
  
  for(var i=0; i < data.modules.length; i++) {
    var moduleListItem = $(moduleList).find("[data-moduleId='" + data.modules[i].moduleId + "']");
    $(moduleListItem).find("div.module input.duration").val(toSTime(data.modules[i].moduleDuration));
    $(moduleListItem).find("div.module input.reservoir").val(toSTime(0));
  }
  
  $(moduleList).find("div.item input.duration").val(toSTime(data.courseItemDuration));
}

//*********************************************
// showUpdatedCourseDuration
//*********************************************

var showUpdatedCourseDuration = function(data) {
  var reservoir = data.courseReservoir;
  //if(reservoir==0) {reservoir="";}
  $(this.listItem).children("div.course").children("input.reservoir").val(toSTime(reservoir));
}

//*********************************************
// showUpdatedModuleDuration
//*********************************************

var showUpdatedModuleDuration = function(data) {
  var reservoir = data.moduleReservoir;
  //if(reservoir==0) {reservoir="";}
  $(this.listItem).children("div.module").children("input.reservoir").val(toSTime(reservoir));

  var courseListItem = $(this.listItem).parent("ul").closest("li");
  var reservoir = data.courseReservoir;
  //if(reservoir==0) {reservoir="";}
  $(courseListItem).children("div.course").children("input.reservoir").val(toSTime(reservoir));
}

//*********************************************
// showUpdatedItemDuration
//*********************************************

var showUpdatedItemDuration = function(data) {
  var moduleListItem = $(this.listItem).parent("ul").closest("li");
  var reservoir = data.moduleReservoir;
  //if(reservoir==0) {reservoir="";}
  $(moduleListItem).children("div.module").children("input.reservoir").val(toSTime(reservoir));
}

//*********************************************
// expandFolder
//*********************************************

function expandFolder(listItem) {
  var span = $(listItem).children("div").children("span.open-close");
  if($(span).hasClass("glyphicon-folder-close")) {
    $(span).removeClass('glyphicon-folder-close').addClass('glyphicon-folder-open');
  }
  var list = $(listItem).children("ul");
  if($(list).hasClass("hidden")) {
    $(list).removeClass("hidden");
  }
}

//*********************************************
// collapseFolder
//*********************************************

function collapseFolder(listItem) {
  var span = $(listItem).children("div").children("span.open-close");
  if($(span).hasClass("glyphicon-folder-open")) {
    $(span).removeClass('glyphicon-folder-open').addClass('glyphicon-folder-close');
  }
  var list = $(listItem).children("ul");
  if(!$(list).hasClass("hidden")) {
    $(list).addClass("hidden");
  }
}

//*********************************************
// expandAllFolders
//*********************************************

function expandAllFolders(lists) {
  $(lists).removeClass('hidden');
  $(lists).parent().children('div.tile').children('span.glyphicon-folder-close').removeClass('glyphicon-folder-close').addClass('glyphicon-folder-open');
}

//*********************************************
// collapseAllFolders
//*********************************************

function collapseAllFolders(lists) {
  $(lists).addClass('hidden');
  $(lists).parent().children('div.tile').children('span.glyphicon-folder-open').removeClass('glyphicon-folder-open').addClass('glyphicon-folder-close');
}

//*********************************************
// initTablesPage
//*********************************************

function initTablesPage() {
  if($("#accounts-table-wrapper").children().length == 0) {
    getAndShowAccountsTable(showError);
  }
  if($("#courses-table-wrapper").children().length == 0) {
    getAndShowCoursesTable(showError);
  }
  if($("#sets-table-wrapper").children().length == 0) {
    getAndShowSetsTable(showError);
  }
  if($("#users-table-wrapper").children().length == 0) {
    getAndShowUsersTable(showError);
  }
}

//*********************************************
// getAndShowSetsTable
//*********************************************

function getAndShowSetsTable(error) {
  $('#sets-table-wrapper').empty();
  var table = $('<table id="sets-table" class="display" cellspacing="0" width="100%">').appendTo('#sets-table-wrapper');
  table.DataTable({
    ajax: {
      type: 'GET',
      headers: {"Authorization": credentials},
      url: easelUrl + '/sets',
      dataType: "json",
      async: false,
      dataSrc: "",
      error: error
    },
    columns: [
      { "data": "setId" , "title": "Set ID" },
      { "data": "name" , "title": "Name" },
      { "data": "parentId" , "title": "Parent ID" },
      { "data": "position" , "title": "Position" }
    ],
    stateSave: true
  });
}

//*********************************************
// getAndShowAccountsTable
//*********************************************

function getAndShowAccountsTable(error) {
  $('#accounts-table-wrapper').empty();
  var table = $('<table id="accounts-table" class="display" cellspacing="0" width="100%">').appendTo('#accounts-table-wrapper');
  table.DataTable({
    ajax: {
      type: 'GET',
      headers: {"Authorization": credentials},
      url: easelUrl + '/accounts',
      dataType: "json",
      async: false,
      dataSrc: "",
      error: error
    },
    columns: [
      { "data": "accountId" , "title": "Account ID" },
      { "data": "name" , "title": "Name" },
      { "data": "parentId" , "title": "Parent ID" },
      { "data": "updated" , "title": "Updated" }
    ],
    stateSave: true
  });
}

//*********************************************
// getAndShowCoursesTable
//*********************************************

function getAndShowCoursesTable(error) {
  $('#courses-table-wrapper').empty();
  var table = $('<table id="courses-table" class="display" cellspacing="0" width="100%">').appendTo('#courses-table-wrapper');
  table.DataTable({
    ajax: {
      type: 'GET',
      headers: {"Authorization": credentials},
      url: easelUrl + '/courses',
      dataType: "json",
      async: false,
      dataSrc: "",
      error: error
    },
    columns: [
      { "data": "courseId" , "title": "Course ID" },
      { "data": "name" , "title": "Name" },
      { "data": "accountId" , "title": "Account ID" },
      { "data": "duration" , "title": "Duration" },
      { "data": "updated" , "title": "Updated" }
    ],
    stateSave: true
  });
}

//*********************************************
// getAndShowUsersTable
//*********************************************

function getAndShowUsersTable(error) {
  $('#users-table-wrapper').empty();
  var table = $('<table id="users-table" class="display" cellspacing="0" width="100%">').appendTo('#users-table-wrapper');
  table.DataTable({
    ajax: {
      type: 'GET',
      headers: {"Authorization": credentials},
      url: easelUrl + '/users',
      dataType: "json",
      async: false,
      dataSrc: "",
      error: error
    },
    columns: [
      { "data": "userId" , "title": "User ID" },
      { "data": "name" , "title": "Name" },
      { "data": "loginId" , "title": "Login ID" },
      { "data": "sisUserId" , "title": "SIS User ID" },
      { "data": "studyRate" , "title": "Study Rate" },
      { "data": "updated" , "title": "Updated" }
    ],
    stateSave: true
  });
}

//*********************************************
// sync-page handlers
//*********************************************

$(document).ready(function() {

  $('#main').delegate("#sync-user", "click", function(e) {
    e.preventDefault();
    var userIdStr = prompt("User ID:", "")
    if(userIdStr != null) {syncUser(parseInt(userIdStr), afterSyncUser, showError);}
  });

  $('#main').delegate("#sync-users", "click", function(e) {
    e.preventDefault();
    if (confirm("Are you sure?")) {syncUsers(afterSyncUsers, showError);}
  });

  $('#main').delegate("#sync-course", "click", function(e) {
    e.preventDefault();
    var courseIdStr = prompt("Course ID:", "")
    if(courseIdStr != null) {syncCourse(parseInt(courseIdStr), afterSyncCourse, showError);}
  });

  $('#main').delegate("#sync-courses", "click", function(e) {
    e.preventDefault();
    if (confirm("Are you sure?")) {syncCourses(afterSyncCourses, showError);}
  });

});

//*********************************************
// showNothing
//*********************************************

var showNothing = function (data) {
}

//*********************************************
// showSuccess
//*********************************************

var showSuccess = function (data) {
  alert(JSON.stringify(data));
}

//*********************************************
// showError
//*********************************************

var showError = function (jqXHR, status, error) {
  var o = JSON.parse(jqXHR.responseText);
  alert(jqXHR.status + ' ' + error);
  //alert(o.message + '\n' + jqXHR.status + ' ' + error);
}

//*********************************************
// dateToString
//*********************************************

function dateToString(d) {
  return d.getFullYear() + '-' + ("0" + (d.getMonth() + 1)).slice(-2) + '-' + ("0" + d.getDate()).slice(-2);
}

//*********************************************
// toITime
//*********************************************

function toITime(sTime) {
  if(sTime == "") {return 0;}
  var sign = 1;
  if(sTime.charAt(0)=="-") {var sign = -1;}
  var hm = sTime.split(":");
  var h = Math.abs(parseInt(hm[0])) * 60;
  var m = parseInt(hm[1]) * 1;
  return sign * (h + m);
}

//*********************************************
// toSTime
//*********************************************

function toSTime(iTime) {
  if(iTime == 0) {return "";}
  iTime = parseInt(iTime);
  var sign = "";
  var m = 0;
  var h = 0;
  if(iTime < 0) {sign = "-";}
  iTime = Math.abs(iTime);
  if(iTime >= 60) {
    m = iTime % 60; 
    h = (iTime - m) / 60;
  } else {
    m = iTime; 
  }
  return sign + h + ":" + pad2(m);
}

//*********************************************
// pad2
//*********************************************

function pad2(n) {
  return (n < 10 ? '0' : '') + n 
}

//*********************************************
// Assignments-page
//*********************************************

$(document).ready(function() {

  $('#assignments-page button.start-over').on('click', function(event) {
    initAssignmentsPage("all");
  });

  $('#assignments-page select.choose-a-student').on('changed.bs.select', function (e, clickedIndex, newValue, oldValue) {
    initAssignmentsPage("choose-a-student");
    var userId = $("#assignments-page select.choose-a-student").find(":selected").val();
    getUserCourses(userId, populateCourseMenu, showError);
    getUser(userId, populateUserTable, showError);
    $(document.activeElement).blur();
  });

  $('#assignments-page select.choose-a-course').on('changed.bs.select', function (e, clickedIndex, newValue, oldValue) {
    initAssignmentsPage("choose-a-course");  
    var courseId = $(e.currentTarget).val();
    var userId = $("#assignments-page select.choose-a-student").find(":selected").val();
    getCourse(courseId, populateCourseTable, showError);
    getAssignmentItems(courseId, populateAssignmentTable, showError);
    getUserOverrides(userId, courseId, showUserOverrides, showError);
    getUserSubmissions(courseId, userId, showUserSubmissions, showError);
    $(document.activeElement).blur();
  });
  
  $('#assignments-page select.choose-an-action').on('changed.bs.select', function (e, clickedIndex, newValue, oldValue) {
    var d = $('#assignments-page div.' + $(e.currentTarget).val());
    $(d).siblings('div').addClass('hidden');
    $(d).removeClass('hidden');
    $('#assignments-page button.hide-action-button').removeClass('hidden');
    $(document.activeElement).blur();
  });

  $('#assignments-page button.hide-action-button').on('click', function(event) {
    hideActionButton();
    //$('#assignments-page div.actions').children('div').addClass('hidden');
    //$('#assignments-page button.hide-action-button').addClass('hidden');
    //$("#assignments-page select.choose-an-action").val('').selectpicker('refresh');
  });

  $('#assignments-page input.start-date').datepicker({
    format: "yyyy-mm-dd",
    todayHighlight: true,
    autoclose: true,
    toggleActive: true
  });

  $('#assignments-page input.start-date').datepicker().on('changeDate', function (ev) {
    generateCalendar();
  });

  $('#assignments-page button.pattern-button').on('click', function(event) {
    var tr = $("#assignments-page table.scheduler-table tbody").find("tr:first");
    var inputs = $(tr).children('td').children('input');
    var durations = [];
    
    $(inputs).each(function() {
      duration = toITime($(this).val());
      if (!duration) {durations.push(0);}
      else {durations.push(duration);}
    });
    
    for(var i=0; i < durations.length; i++) {
      if(durations[i] > 0) {
        $('#assignments-page table.scheduler-table tbody tr td:nth-child(' + (i+1) + ')').children('input').val(toSTime(durations[i]));
      }
    }
  });

  $('#assignments-page div.create-due-dates button.propose-button').on('click', function(event) {

    var dd = []; // elapseds and accumulating durations
    var elapsed = 0;
    
    var inputs = $("#assignments-page table.scheduler-table tbody td input")
    $(inputs).each(function() {
      duration = toITime($(this).val());
      if (duration) {
        elapsed += duration;
        var dueDate = $(this).data("date");
        dd.push([elapsed, dueDate]);
      }
    });
    
    var assignments = $("#assignments-page table.assignments-table tbody tr");
    $(assignments).each(function() {
      var elapsed = toITime($(this).children("td.elapsed").html());
      for(var i=0; i < dd.length; i++) {
        if(elapsed < dd[i][0]) {
          var dueDate = new Date(dd[i][1]);
          if(!$(this).children("td.completed").html()) {
            $(this).children("td.proposedDate").children('input').datepicker('update', dateToString(dueDate));
            $(this).children("td.proposedTime").children('input').val("17:00");
          }
          break;
        }
      }
    });

  });

  $('#assignments-page div.modify-due-dates button.propose-button').on('click', function(event) {
    var minToAdd = new Date().getTimezoneOffset();
    var daysToAdd = parseInt($("#assignments-page div.modify-due-dates input.days-to-add").val(), 10);
    var assignments = $("#assignments-page table.assignments-table tbody tr");
    $(assignments).each(function() {
      if($(this).children('td.dueDateCheck').children('input').is(':checked')) {
        var dueDate = new Date($(this).children("td.dueDate").html());
        dueDate.setDate(dueDate.getDate() + daysToAdd);
        dueDate.setMinutes(dueDate.getMinutes() + minToAdd);
        $(this).children("td.proposedDate").children('input').datepicker('update', dueDate);
        $(this).children("td.proposedTime").children('input').val("17:00");
      }
    });
  }); 

  $("#assignments-page").delegate("table.scheduler-table input", "keydown", function(e) {

    // Enter
    if(e.which == 13) {
      e.preventDefault();
      var v = toSTime($(this).val() * 60);
      $(this).val(v)
      $(this).blur();
    }

    // Tab
    else if(e.which == 9) {
      var v = toSTime($(this).val() * 60);
      $(this).val(v)
    }

    // Escape
    else if(e.which == 27) {
      e.preventDefault();
      $(this).blur();
    }
  });

  $('#assignments-page table.assignments-table th.dueDateCheck input').change(function() {
    if($(this).is(':checked')) {
      var rows = $("#assignments-page table.assignments-table tbody tr");
      $(rows).each(function() {
        if($(this).children("td.dueDate").html() && !$(this).children("td.completed").html()) {
          $(this).children("td.dueDateCheck").children("input").prop("checked", true);
        }
      });
    } else {
      $("#assignments-page table.assignments-table td.dueDateCheck input").prop("checked", false);
    }
  });

  $('#assignments-page button.add-assignments').on('click', function(event) {

    var courseId = $("#assignments-page select.choose-a-course").find(":selected").val();
    var data = new Object();
    data.userId = $("#assignments-page select.choose-a-student").find(":selected").val();
    data.userName = $("#assignments-page select.choose-a-student").find(":selected").html();
    data.assignmentId = [];
    data.dueDate = [];
    data.overrideId = []; // Old one. Delete this one before creating a new one.

    var rows = $("#assignments-page table.assignments-table tbody tr");
    $(rows).each(function() {
      var date = $(this).children("td.proposedDate").children("input").datepicker("getDate");
      if(date) {

        var assignmentId = parseInt($(this).data("assignmentid"));
        data.assignmentId.push(assignmentId);
        
        var dueTime = $(this).children("td.proposedTime").children("input").val();

        // var dueDate = dateToString(date) + "T21:00:00Z";
        var dueDate = dateToString(date) + "T" + dueTime + ":00Z";
        data.dueDate.push(dueDate);

        var overrideId = $(this).data("overrideid");
        if(overrideId) {
          overrideId = parseInt(overrideId);
          $(this).removeData("overrideid").removeAttr("data-overrideid");
        }
        data.overrideId.push(overrideId);
      }
    });

    /*
    if(confirm(''
      + 'Course ID = ' + courseId + '\n'
      + 'User ID = ' + data.userId + '\n'
      + 'User Name = ' + data.userName + '\n'
      + 'Assignment Ids = ' + data.assignmentId + '\n'
      + 'Due Dates = ' + data.dueDate + '\n'
      + 'Override Ids = ' + data.overrideId + '\n'
    )) {postAssignments(courseId, data, afterPostAssignments, showError);}
    */

    postAssignments(courseId, data, afterPostAssignments, showError);

  });

  $('#assignments-page button.delete-assignments').on('click', function(event) {
    var courseId = $("#assignments-page select.choose-a-course").find(":selected").val();
    var data = new Object();
    data.assignmentId = [];
    data.overrideId = [];

    var rows = $("#assignments-page table.assignments-table tbody tr");
    $(rows).each(function() {
      var checked = $(this).children('td.dueDateCheck').children('input').is(':checked');
      if(checked) {
        data.assignmentId.push($(this).data("assignmentid"));
        data.overrideId.push($(this).data("overrideid"));
      }
    });

    /*
    if(confirm(''
      + 'Course ID = ' + courseId + '\n'
      + 'Assignment IDs = ' + data.assignmentId + '\n'
      + 'Override IDs = ' + data.overrideId + '\n'
    )) {deleteAssignments(courseId, data, afterDeleteAssignments, showError);}
    */
    
    deleteAssignments(courseId, data, afterDeleteAssignments, showError);
  });

  $('#assignments-page button.refresh-assignments').on('click', function(event) {

    $("#assignments-page table.assignments-table th.dueDateCheck input").prop("checked", false);
    $("#assignments-page table.assignments-table td.dueDateCheck input").prop("checked", false);
    $("#assignments-page table.assignments-table tbody tr td.proposedDate").datepicker('update', '');
    $("#assignments-page table.assignments-table tbody tr td.proposedTime input").val("");

    var courseId = $("#assignments-page select.choose-a-course").find(":selected").val();
    var userId = $("#assignments-page select.choose-a-student").find(":selected").val();
    getUserSubmissions(courseId, userId, showUserSubmissions, showError);
  });

});

//*********************************************
// initAssignmentsPage
//*********************************************

function initAssignmentsPage(level) {

  if (typeof(level)==='undefined') level = "all";

  switch(level) {

    case "all":
      if($("#assignments-page select.choose-a-student > option").length == 1) {
        getUsers(populateUserMenu, showError);
      } else {
        $("#assignments-page select.choose-a-student").val('');
        $("#assignments-page select.choose-a-student").selectpicker('refresh');
      }
      $("#assignments-page table.user-table tbody td.studyRate").html('');

    case "choose-a-student":
      $("#assignments-page select.choose-a-course").val('');
      $("#assignments-page select.choose-a-course").find('option:not(.bs-title-option)').remove();
      $("#assignments-page select.choose-a-course").selectpicker('refresh');
      $("#assignments-page table.course-table tbody td.duration").html('');
      initDueDatesTable();

    case "choose-a-course":
    case "choose-an-action": 
      initCalendar();
      $("#assignments-page input.days-to-add").val('');
      hideActionButton();
      break;
  }
}

//*********************************************
// hideActionButton
//*********************************************

function hideActionButton() {
  $('#assignments-page div.actions').children('div').addClass('hidden');
  $('#assignments-page button.hide-action-button').addClass('hidden');
  $("#assignments-page select.choose-an-action").val('').selectpicker('refresh');
}

//*********************************************
// initDueDatesTable
//*********************************************

function initDueDatesTable() {
  $("#assignments-page table.assignments-table th.dueDateCheck input").prop("checked", false);
  $("#assignments-page table.assignments-table tbody").empty();
  for(var i=0; i < 4; i++) {
    $("#assignments-page table.assignments-table tbody").append(''
      + '<tr>'
      + '<td class="index">&nbsp;</td>'
      + '<td class="assignment">&nbsp;</td>'
      + '<td class="elapsed">&nbsp;</td>'
      + '<td class="proposedDate"><input type="text" disabled></td>'
      + '<td class="proposedTime"><input type="text" disabled></td>'
      + '<td class="dueDate">&nbsp;</td>'
      + '<td class="dueTime">&nbsp;</td>'
      + '<td class="dueDateCheck"><input type="checkbox"></td>'
      + '<td class="completed">&nbsp;</td>'
      + '</tr>'
    );
  }
}

//*********************************************
// populateAssignmentTable
//*********************************************

var populateAssignmentTable = function(data) {
  $("#assignments-page table.assignments-table tbody").empty();
  for(var i=0; i < data.length; i++) {
    var item = data[i];
    $("#assignments-page table.assignments-table tbody").append(''
      + '<tr data-assignmentId="' + data[i].assignmentId + '">'
      + '<td class="index">' + (i+1) + '</td>'
      + '<td class="assignment">' + item.name + '</td>'
      + '<td class="elapsed">' + toSTime(item.elapsed) + '</td>'
      + '<td class="proposedDate"><input type="text"></td>'
      + '<td class="proposedTime"><input type="text"></td>'
      + '<td class="dueDate"></td>'
      + '<td class="dueTime"></td>'
      + '<td class="dueDateCheck"><input type="checkbox"></td>'
      + '<td class="completed"></td>'
      + '</tr>'
    );
  }

  $('#assignments-page td.proposedDate input').datepicker({
    format: "yyyy-mm-dd",
    todayHighlight: true,
    autoclose: true,
    clearBtn: true,
    toggleActive: true
  });

  $('#assignments-page td.proposedDate input').datepicker().on('changeDate', function (ev) {
    $(this).closest('tr').children('td.proposedTime').children('input').val('17:00');
  });

}

//*********************************************
// populateCourseMenu
//*********************************************

var populateCourseMenu = function(data) {
  for(var i=0; i < data.length; i++) {
    $("#assignments-page select.choose-a-course").append(''
      + '<option  value="' + data[i].courseId + '"data-duration = "' + data[i].duration + '">' 
      + '<span>' + data[i].name + '</span>'
      + '</option>');
  }
  $("#assignments-page select.choose-a-course").selectpicker('refresh');
}

//*********************************************
// populateCourseTable
//*********************************************

var populateCourseTable = function(data) {
  $("#assignments-page table.course-table tbody td.duration").html(toSTime(data.duration));
}

//*********************************************
// populateUserMenu
//*********************************************

var populateUserMenu = function(data) {
  for(var i=0; i < data.length; i++) {
    $("#assignments-page select.choose-a-student").append(''
      + '<option  value="' + data[i].userId + '">' 
      + '<span>' + data[i].name + '</span>'
      + '</option>');
  }
  $("#assignments-page select.choose-a-student").selectpicker('refresh');
}

//*********************************************
// populateUserTable
//*********************************************

var populateUserTable = function(data) {
  $("#assignments-page table.user-table tbody td.studyRate").html(toSTime(data.studyRate));
}

//*********************************************
// initCalendar
//*********************************************

var initCalendar = function() {
  $("#assignments-page input.start-date").datepicker('update', '');
  $("#assignments-page table.scheduler-table tbody").empty();
  for(var i=0; i < 4; i++) {
    var s = '<tr>';
    for(var j=0; j < 7; j++) {
      s = s + '<td><input class="pull-right"></input></td>';
    }
    var s = s + '</tr>';
    $("#assignments-page table.scheduler-table tbody").append(s);
  }
}

//*********************************************
// generateCalendar
//*********************************************

var generateCalendar = function() {

  var x = $("#assignments-page input.start-date").val();
  
  if(!x) { initCalendar(); return; }

  var startDate = new Date(x);
  var courseTime = $("#assignments-page select.choose-a-course").find(":selected").data("duration");
  var studyRate = toITime($("#assignments-page table.user-table td.studyRate").html());
  var numWeeks = Math.ceil(courseTime / studyRate) + 1;
  var dayOfWeek = startDate.getDay();
  var current = new Date(startDate);
  current.setDate(current.getDate() - dayOfWeek);

  $("#assignments-page table.scheduler-table tbody").empty();

  /*
  alert(''
    + 'Course Time = ' + courseTime + '\n'
    + 'Study Rate  = ' + studyRate + '\n'
    + 'Num Weeks   = ' + numWeeks + '\n'
    + 'Start Date  = ' + startDate.toDateString() + '\n'
    + 'Sunday      = ' + current.toDateString() + '\n'
    + 'Month       = ' + current.getMonth() + '\n'
    + 'Date        = ' + current.getDate() + '\n'
  );
  */

  for(var i=0; i < numWeeks; i++) {

    var date0 = new Date(current);
    var date1 = new Date(current);
    var date2 = new Date(current);
    var date3 = new Date(current);
    var date4 = new Date(current);
    var date5 = new Date(current);
    var date6 = new Date(current);

    date1.setDate(date1.getDate() + 1);
    date2.setDate(date2.getDate() + 2);
    date3.setDate(date3.getDate() + 3);
    date4.setDate(date4.getDate() + 4);
    date5.setDate(date5.getDate() + 5);
    date6.setDate(date6.getDate() + 6);
    
    day0 = (date0.getMonth() + 1) + '/' + date0.getDate();
    day1 = (date1.getMonth() + 1) + '/' + date1.getDate();
    day2 = (date2.getMonth() + 1) + '/' + date2.getDate();
    day3 = (date3.getMonth() + 1) + '/' + date3.getDate();
    day4 = (date4.getMonth() + 1) + '/' + date4.getDate();
    day5 = (date5.getMonth() + 1) + '/' + date5.getDate();
    day6 = (date6.getMonth() + 1) + '/' + date6.getDate();


    $("#assignments-page table.scheduler-table tbody").append(''
      + '<tr>'
      + '<td class="sun"><span class="date pull-left">' + day0 + '</span><input class="duration pull-right" data-date = "' + date0.getTime() + '"></input></td>'
      + '<td class="mon"><span class="date pull-left">' + day1 + '</span><input class="duration pull-right" data-date = "' + date1.getTime() + '"></input></td>'
      + '<td class="tue"><span class="date pull-left">' + day2 + '</span><input class="duration pull-right" data-date = "' + date2.getTime() + '"></input></td>'
      + '<td class="wed"><span class="date pull-left">' + day3 + '</span><input class="duration pull-right" data-date = "' + date3.getTime() + '"></input></td>'
      + '<td class="thu"><span class="date pull-left">' + day4 + '</span><input class="duration pull-right" data-date = "' + date4.getTime() + '"></input></td>'
      + '<td class="fri"><span class="date pull-left">' + day5 + '</span><input class="duration pull-right" data-date = "' + date5.getTime() + '"></input></td>'
      + '<td class="sat"><span class="date pull-left">' + day6 + '</span><input class="duration pull-right" data-date = "' + date6.getTime() + '"></input></td>'
      + '</tr>'
    );

    current.setDate(current.getDate() + 7);
  }
}

//*********************************************
// afterPostAssignments
// [
// {"id":208,"assignment_id":413,"title":"Joe Hagen","due_at":"2017-03-30T21:00:00Z","all_day":false,"all_day_date":"2017-03-30","student_ids":[48]},
// {"id":209,"assignment_id":407,"title":"Joe Hagen","due_at":"2017-04-03T21:00:00Z","all_day":false,"all_day_date":"2017-04-03","student_ids":[48]},
// {"id":210,"assignment_id":410,"title":"Joe Hagen","due_at":"2017-04-03T21:00:00Z","all_day":false,"all_day_date":"2017-04-03","student_ids":[48]},
// {"id":211,"assignment_id":405,"title":"Joe Hagen","due_at":"2017-04-13T21:00:00Z","all_day":false,"all_day_date":"2017-04-13","student_ids":[48]},
// {"id":212,"assignment_id":408,"title":"Joe Hagen","due_at":"2017-04-17T21:00:00Z","all_day":false,"all_day_date":"2017-04-17","student_ids":[48]},
// {"id":213,"assignment_id":411,"title":"Joe Hagen","due_at":"2017-04-18T21:00:00Z","all_day":false,"all_day_date":"2017-04-18","student_ids":[48]},
// {"id":214,"assignment_id":406,"title":"Joe Hagen","due_at":"2017-04-27T21:00:00Z","all_day":false,"all_day_date":"2017-04-27","student_ids":[48]},
// {"id":215,"assignment_id":409,"title":"Joe Hagen","due_at":"2017-05-01T21:00:00Z","all_day":false,"all_day_date":"2017-05-01","student_ids":[48]},
// {"id":216,"assignment_id":412,"title":"Joe Hagen","due_at":"2017-05-02T21:00:00Z","all_day":false,"all_day_date":"2017-05-02","student_ids":[48]}
// ]
//*********************************************

var afterPostAssignments = function(data) {
  var rows = $("#assignments-page table.assignments-table tbody tr");
  for(var i=0; i < data.length; i++) {
    var assignmentId = data[i].assignment_id;
    var overrideId = data[i].id;
    var dueDate = data[i].due_at;
    var row = $(rows).filter('[data-assignmentid="' + assignmentId + '"]');
    $(row).attr("data-overrideid", overrideId);
    $(row).children('td.proposedDate').children("input").datepicker('update', '');
    $(row).children('td.proposedTime').children("input").val("");
    $(row).children('td.dueDate').html(dueDate.substring(0, 10));
    $(row).children('td.dueTime').html(dueDate.substring(11, 16));
  }
}

//*********************************************
// afterDeleteAssignments
//*********************************************

var afterDeleteAssignments = function(data) {
  var rows = $("#assignments-page table.assignments-table tbody tr");
  for(var i=0; i < data.length; i++) {
    var assignmentId = data[i].assignment_id;
    var row = $(rows).filter('[data-assignmentid="' + assignmentId + '"]');
    $(row).removeData("overrideid").removeAttr("data-overrideid");
    $(row).children('td.dueDate').html('');
    $(row).children('td.dueTime').html('');
    $(row).children('td.dueDateCheck').children('input').prop( "checked", false );
  }
  $('#assignments-page table.assignments-table th.dueDateCheck input').prop( "checked", false );
}

//*********************************************
// showUserOverrides
//*********************************************

var showUserOverrides = function(data) {
  var assignments = $("#assignments-page table.assignments-table tbody tr");
  for(var i=0; i < data.length; i++) {
    var assignmentId = data[i].id;
    var overrideId = data[i].all_dates[0].id;
    var dueDate = data[i].all_dates[0].due_at;
    if(overrideId && dueDate) {
      var tr = $(assignments).filter('[data-assignmentid="' + assignmentId + '"]');
      $(tr).attr("data-overrideid", overrideId);
      $(tr).children('td.dueDate').html(dueDate.substring(0, 10));
      $(tr).children('td.dueTime').html(dueDate.substring(11, 16));
    }
  }
}

//*********************************************
// showUserSubmissions
//*********************************************

var showUserSubmissions = function(data) {
  var assignments = $("#assignments-page table.assignments-table tbody tr");
  for(var i=0; i < data.length; i++) {
    var assignmentId = data[i].assignment_id;
    var submittedAt = data[i].submitted_at;
    if(submittedAt) {
      var td = $(assignments).filter('[data-assignmentid="' + assignmentId + '"]').find('td.completed');
      $(td).html(submittedAt.substring(0, 10));
    }
  }
}

//******************************************************************************************
// .ajax
//******************************************************************************************

//*********************************************
// deleteAssignments
//*********************************************

function deleteAssignments(courseId, data, success, error) {
  $.ajax( {
    type: 'DELETE',
    headers: {"Authorization": credentials},
    url: easelUrl + '/canvas/courses/' + courseId + '/assignments',
    data: JSON.stringify(data),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// deleteSet
//*********************************************

function deleteSet(setId, success, error) {
  $.ajax( {
    type: 'DELETE',
    headers: {"Authorization": credentials},
    url: easelUrl + '/sets/' + setId,
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// getAssignmentItems
//*********************************************

function getAssignmentItems(courseId, success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/courses/' + courseId + '/assignmentitems',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// getCourse
//*********************************************

function getCourse(courseId, success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/courses/' + courseId,
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// getCourses
//*********************************************

function getCourses(success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/courses',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// getItems
//*********************************************

function getItems(moduleId, list, success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    list: list,
    url: easelUrl + '/modules/' + moduleId + '/items',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// getModules
//*********************************************

function getModules(courseId, list, success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    list: list,
    url: easelUrl + '/courses/' + courseId + '/modules',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

/**********************************************
* getPermission
**********************************************/

function getPermission(error) {
  var loginId = $('#loginId-input').val();
  var password = $('#password-input').val();
  credentials = "Basic " + btoa(loginId + ":" + password);
  //$('#loginId-input').val('');
  //$('#password-input').val('');
  
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/users/authenticate',
    dataType: "json",
    async: false,
    success: function (data) {
      authenticated = 1;
      $(".login").addClass("hidden");
      $(".logout").removeClass("hidden");
      initDurationsPage();
      initTablesPage();
      initAssignmentsPage();
    },
    error: error
  });
}

//*********************************************
// getSubAccountsAndCourses
//*********************************************

function getSubAccountsAndCourses(success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/accounts/0/subaccounts/courses',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// getSubsetsAndCourses
//*********************************************

function getSubsetsAndCourses(success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/sets/0/subsets/courses',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// syncUser
//*********************************************

function syncUser(userId, success, error) {

  // $("#users-table-wrapper").empty();

  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/sync/users/' + userId,
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// afterSyncUser
//*********************************************

var afterSyncUser = function (data) {
  alert("Elapsed time: " + JSON.stringify(data) + " seconds");
  getAndShowUsersTable(showError);
}

//*********************************************
// syncUsers
//*********************************************

function syncUsers(success, error) {

  $("#users-table-wrapper").empty();

  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/sync/users',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// afterSyncUsers
//*********************************************

var afterSyncUsers = function (data) {
  alert("Elapsed time: " + JSON.stringify(data) + " seconds");
  getAndShowUsersTable(showError);
}

//*********************************************
// syncCourse
//*********************************************

function syncCourse(courseId, success, error) {

  // $("#courses-table-wrapper").empty();

  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/sync/courses/' + courseId,
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// afterSyncCourse
//*********************************************

var afterSyncCourse = function (data) {
  alert("Elapsed time: " + JSON.stringify(data) + " seconds");
  getAndShowAccountsTable(showError);
  getAndShowCoursesTable(showError);
  getSubAccountsAndCourses(showSubAccountsAndCourses, showError);
}

//*********************************************
// syncCourses
//*********************************************

function syncCourses(success, error) {

  $("#courses-table-wrapper").empty();

  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/sync/courses',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// afterSyncCourses
//*********************************************

var afterSyncCourses = function (data) {
  alert("Elapsed time: " + JSON.stringify(data) + " seconds");
  getAndShowAccountsTable(showError);
  getAndShowCoursesTable(showError);
  getSubAccountsAndCourses(showSubAccountsAndCourses, showError);
}

//*********************************************
// getUser
//*********************************************

function getUser(userId, success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/users/' + userId,
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// getUserOverrides
//*********************************************

function getUserOverrides(userId, courseId, success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/canvas/users/' + userId + '/courses/' + courseId + '/assignments',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// getUserCourses
//*********************************************

function getUserCourses(userId, success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/users/' + userId + '/courses',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// getUserSubmissions
//*********************************************

function getUserSubmissions(courseId, userId, success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/canvas/courses/' + courseId + '/students/' + userId + '/submissions',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// getUsers
//*********************************************

function getUsers(success, error) {
  $.ajax( {
    type: 'GET',
    headers: {"Authorization": credentials},
    url: easelUrl + '/users',
    dataType: "json",
    async: false,
    success: success,
    error: error
  });
}

//*********************************************
// linkSetAndCourses
//*********************************************

function linkSetAndCourses(setLI, success, error) {
  var setId = $(setLI).data("setid");
  var courses = $(setLI).children("ul").children("li");
  var courseIds = [];         
  for (var i = 0; i < courses.length; i++) {
    courseIds.push($(courses[i]).data("courseid"));
  }

  $.ajax( {
    type: 'LINK',
    headers: {"Authorization": credentials},
    url: easelUrl + '/sets/'+ setId + '/courses',
    data: JSON.stringify(courseIds),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// postAssignment
//*********************************************

function postAssignment(success, error) {
  var data = new Object();
  data.userId = 48;
  data.userName = "Joe Hagen";
  data.dueDate = "2017-02-05T00:47:16Z";

  $.ajax( {
    type: 'POST',
    headers: {"Authorization": credentials},
    url: easelUrl + '/canvas/courses/20/assignments/413',
    data: JSON.stringify(data),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// postAssignments
//*********************************************

function postAssignments(courseId, data, success, error) {
  $.ajax( {
    type: 'POST',
    headers: {"Authorization": credentials},
    url: easelUrl + '/canvas/courses/' + courseId + '/assignments',
    data: JSON.stringify(data),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// postSet
//*********************************************

function postSet(set, list, success, error) {
  $.ajax( {
    type: 'POST',
    headers: {"Authorization": credentials},
    list: list,
    url: easelUrl + '/sets',
    data: JSON.stringify(set),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// putCourseDuration
//*********************************************

function putCourseDuration(courseId, listItem, duration, success, error) {  
  $.ajax( {
    type: 'PUT',
    headers: {"Authorization": credentials},
    listItem: listItem,
    url: easelUrl + '/courses/' + courseId + '/duration',
    data: JSON.stringify(duration),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// putCourseDurations
//*********************************************

function putCourseDurations(courseId, listItem, success, error) {  
  $.ajax( {
    type: 'PUT',
    headers: {"Authorization": credentials},
    listItem: listItem,
    url: easelUrl + '/courses/' + courseId + '/durations',
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// putItemDuration
//*********************************************

function putItemDuration(itemId, listItem, duration, success, error) {  
  $.ajax( {
    type: 'PUT',
    headers: {"Authorization": credentials},
    listItem: listItem,
    url: easelUrl + '/items/' + itemId + '/duration',
    data: JSON.stringify(duration),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// putModuleDuration
//*********************************************

function putModuleDuration(moduleId, listItem, duration, success, error) {  
  $.ajax( {
    type: 'PUT',
    headers: {"Authorization": credentials},
    listItem: listItem,
    url: easelUrl + '/modules/' + moduleId + '/duration',
    data: JSON.stringify(duration),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// putSetDuration
//*********************************************

function putSetDuration(setId, duration, success, error) {  
  $.ajax( {
    type: 'PUT',
    headers: {"Authorization": credentials},
    url: easelUrl + '/sets/' + setId + '/duration',
    data: JSON.stringify(duration),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

//*********************************************
// putSetName
//*********************************************

function putSetName(setId, name, success, error) {  
  $.ajax( {
    type: 'PUT',
    headers: {"Authorization": credentials},
    url: easelUrl + '/sets/' + setId + '/name',
    data: JSON.stringify(name),
    contentType: 'application/json',
    dataType: "json",
    success: success,
    error: error
  });
}

