
$(document).ready(function() {

  $('#toITime').on('click', function(event) {
    var sTime = $('#sTime').val();
    var iTime = toITime(sTime);
    $('#iTime').val(iTime);
  });

  $('#toSTime').on('click', function(event) {
    var iTime = $('#iTime').val();
    var sTime = toSTime(iTime);
    $('#sTime').val(sTime);
  });

  $('#clear').on('click', function(event) {
    $('#iTime').val("");
    $('#sTime').val("");
  });

});

function toITime(sTime) {
  var sign = 1;
  if(sTime.charAt(0)=="-") {var sign = -1;}
  var hm = sTime.split(":");
  var h = Math.abs(parseInt(hm[0])) * 60;
  var m = parseInt(hm[1]) * 1;
  return sign * (h + m);
}

function toSTime(iTime) {
  iTime = parseInt(iTime);
  var sign = "";
  var m = 0;
  var h = 0;
  if(iTime < 0) {sign = "-";}
  iTime = Math.abs(iTime);
  if(iTime >= 60) {
    m = iTime % 60; 
    h = (iTime - m) / 60;
  } else {
    m = iTime; 
  }
  return sign + h + ":" + pad2(m);
}

function pad2(n) {
  return (n < 10 ? '0' : '') + n 
}