### Introduction

Easel is a web application that supplements Canvas LMS with features related to independent study such as calculating, assigning, and adjusting individualized assignment due dates.

Easel is a prototype only. It is not production ready.

To see Easel v0.02 in action, click [Use Cases for Managing Independent Study](https://community.canvaslms.com/thread/15450-use-cases-for-managing-independent-study).

See also [Easel 0.02 Experimentation Guide](https://hagenhaus.com/wp/?p=1867).
